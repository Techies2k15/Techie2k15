#include<iostream>
#include<fstream>
#include<graphics.h>
#include<string.h>
#define INFINITY 99999

using namespace std;

int mat[30][30];
int n,source;
void initmatrix()
{
    int i,j;
    for(i=0; i<15; i++)
    {
        for(j=0; j<15; j++)
        {
            mat[i][j]=INFINITY;
        }
    }
}
class link;

class node
{
public:
    string data;
    int index;
    int x;
    int y;
    int predecessor[15],distance[15];
    int mark[15];
    node *next;
    link *adj;
    void initialize();
    int getClosestUnmarkedNode();
    void calculateDistance();
    void printDistance();
    void output();
    node* printPath(int);
    node()
    {
        data='\0';
        next=NULL;
        adj=NULL;
    }
};

class link
{
public:
    int dist;
    node *next;
    link *adj;

    link()
    {
        dist=0;
        next=NULL;
        adj=NULL;
    }
};

node *a,*b,*start;
link *c,*d;

void create()
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"d:\\tc\\bgi");
    string data;
    char data1[30];
    int i,x,y;
    int flag=0,dist;
    static int z=0;
    fstream file;
    setcolor(14);
    outtextxy(190,0,"INDIAN MAP-Some imp states transport graph");
    file.open("findata.dat");
    cout<<"\t\tTHE CITIES IN THE MAP ARE: \n";
    cout<<"\t\t--- ------ -- --- ----- --- \n";
    int count1=0;
    while(!file.eof())
    {
        file>>data>>x>>y;
        cout<<count1<<"\t"<<data<<"\n";
        count1++;
        /*if(data=="0")
        {
            break;
        }*/
        b=new node;
        b->data=data;
        b->index=z;
        b->x=x;
        b->y=y;
        i=0;
        data1[0]='\0';

        while(data[i]!='\0')
        {
            data1[i]=data[i];
            i++;
        }
        data1[i]='\0';
        setcolor(5);
        outtextxy(x,y,data1);
        z++;
        n=z;
        if(flag==0)
        {
            start=b;
            a=b;
            flag++;
        }
        else
        {
            a->next=b;
            a=b;
        }
    }
    b=start;
    fstream file1;
    file1.open("route.dat");
    while(b!=NULL)
    {

        flag=0;
        file1>>data>>dist;
        while(1)
        {

            if(data=="END")
            {
                break;
            }
            mat[b->index][b->index]=0;
            if(data=="0")
                break;
            c=new link;
            c->dist=dist;
            if(flag==0)
            {
                b->adj=c;
                d=c;
                flag++;
            }
            else
            {
                d->adj=c;
                d=c;
            }
            a=start;
            while(a!=NULL)
            {
                if(a->data==data)
                {
                    c->next=a;
                    mat[b->index][a->index]=dist;
                    mat[a->index][b->index]=dist;
                    setcolor(1);
                    line(b->x+10,b->y,a->x+10,a->y);

                }
                a=a->next;
            }
            file1>>data>>dist;
        }

        b=b->next;
    }

}

node* findn(node* start,int n)
{
    node* temp=start;
    for(int i=0; i<n; i++)
        temp=temp->next;
    return temp;
}
void node::initialize()
{
    for(int i=0; i<n; i++)
    {
        mark[i] =0;
        predecessor[i] = -1;
        distance[i] = INFINITY;
    }
    distance[source]= 0;
}


int node::getClosestUnmarkedNode()
{
    int minDistance = INFINITY;
    int closestUnmarkedNode;
    for(int i=0; i<n; i++)
    {
        if((!mark[i]) && ( minDistance >= distance[i]))
        {
            //cout<<"\n"<<distance[i];
            minDistance = distance[i];
            closestUnmarkedNode = i;
        }
    }
    return closestUnmarkedNode;
}


void node::calculateDistance()
{
    initialize();
    int minDistance = INFINITY;
    int closestUnmarkedNode;
    int count = 0;

    int minIndex=-1;

    while(count < n)
    {
        closestUnmarkedNode = getClosestUnmarkedNode();

        mark[closestUnmarkedNode] = 1;

        for(int i=0; i<n; i++)
        {
            if((!mark[i]) && (mat[closestUnmarkedNode][i]>0) )
            {
                if(distance[i] > distance[closestUnmarkedNode]+mat[closestUnmarkedNode][i])
                {
                    distance[i] = distance[closestUnmarkedNode]+mat[closestUnmarkedNode][i];
                    predecessor[i] = closestUnmarkedNode;
                    minIndex=i;
                }
            }
        }

        count++;
    }
}


node* node::printPath(int i)
{
    /*  if(node == source)
          cout<<findn(start,node)->data<<"..";
      else if(predecessor[node] == -1)
          cout<<"No path from "<<source<< "to " <<findn(start,node)->data<<endl;
      else {
          printPath(predecessor[node]);
          cout<<findn(start,node)->data<<"..";
      }*/
    node* s=findn(start,i);
    if(i==source)
    {
        cout<<"From: "<<s->data<<" ---> ";
        return s;
    }
    else if(predecessor[i] == -1)
    {
        cout<<"No path from "<<source<< "----> " <<s->data<<endl;
        exit(0);
    }
    else
    {
        node* d=printPath(predecessor[i]);
        cout<<s->data<<" ---> ";
        setcolor(9);
        line(d->x+10,d->y,s->x+10,s->y);
        return s;
    }
}


void node::output()
{
    /* for(int i=0;i<n;i++) {
         if(i == source)
             cout<<findn(start,i)->data<<".."<<source;
         else
             printPath(i);
         cout<<"->"<<distance[i]<<endl;
     }*/
    cout<<"--------------------------------------------------------------------------------\n";
    cout<<"----------------------------";
    cout<<"ENTER THE CITIES (NUM) ";
    cout<<"-----------------------------\n";
    cout<<"--------------------------------------------------------------------------------\n";
    cout<<"\n\tENTER THE SOURCE VERTEX (NUM): ";


    cin>>source;
    int d;
    cout<<"\n\tENTER THE DESTINATION VERTEX (NUM): ";
    cin>>d;
    cout<<"\n\t\t\t\t\tROUTE:";
    cout<<"\n\t\t\t\t\t-----\n";
    printPath(d);
    cout<<"You've Reached\n";
    cout<<"\n\t\t\tShortest Distance :"<<distance[d];
}
void node::printDistance(){
for (int i=0;i<n;i++){
    cout<<"\n"<<distance[i]<<"\t";
}
}
int main()
{
    int i,j;
    initmatrix();
    create();
    cout<<"\n";
    /*for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            cout<<mat[i][j]<<"\t";
        }
        cout<<"\n";
    }*/
    node s;
    s.calculateDistance();
    //s.printDistance();
    s.output();
    getch();
}

