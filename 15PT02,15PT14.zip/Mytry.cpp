#include<iostream>
#include<cstring>
#include<stdio.h>
#include<fstream>
using namespace std;
float spam=0,ham=0;
class bloomfilter
{
    public:
    int a[70][8];
    int q=10;
    void init()
    {
        for(int i=0;i<70;i++)
            for(int j=0;j<8;j++)
                a[i][j]=0;
    }
    int calculatevalue(float prob)
    {
//        if(prob<0.1)
//            return 0;
//        else if(prob<0.2)
//            return 1;
         if(prob<0.3)
            return 2;
        else if(prob<0.4)
            return 3;
        else if(prob<0.5)
            return 4;
        else if(prob<0.6)
            return 5;
        else if(prob<0.7)
            return 6;
        else if(prob<0.8)
            return 7;
        else if(prob<0.9)
            return 8;
        else
            return 9;

    }
    int hashone(char word[])
    {
        int l=strlen(word);
        int sum=0;
        for(int i=0;i<l;i++)
        {
            sum+=int(word[i]);
        }
        sum=sum%70;
        return sum;
    }
    int hashtwo(char word[])
    {
        int l=strlen(word);
        int sum=0;
        for(int i=0;i<l;i+=2)
        {
            sum+=int(word[i]);
        }
        sum=sum%70;
        return sum;
    }
    int hashthree(char word[])
    {
        int l=strlen(word);
        int sum=0;
        for(int i=0;i<l;i+=3)
        {
            sum+=int(word[i]);
        }
        sum=sum%70;
        return sum;
    }
    int hashfour(char word[])
    {
        int l=strlen(word);
        int sum=0;
        for(int i=0;i<l;i+=4)
        {
            sum+=int(word[i]);
        }
        sum=sum%70;
        return sum;
    }
    void display()
    {
        for(int i=0;i<70;i++)
        {
            for(int j=0;j<8;j++)
                cout<<a[i][j]<<" ";
            cout<<endl;
        }
    }
    void insert(float prob,char word[])
    {   int j,k1,k2,k3,k4;
        int assocvalue=calculatevalue(prob);
        int key1=hashone(word);
        int key2=hashtwo(word);
        int key3=hashthree(word);
        int key4=hashfour(word);
        j=assocvalue;
        j-=2;
        k1=key1;
        k2=key2;
        k3=key3;
        k4=key4;
        cout<<endl<<"j:"<<j;
        cout<<endl<<"k1:"<<k1;
        cout<<endl<<"k2:"<<k2;
        cout<<endl<<"k3:"<<k3;
        cout<<endl<<"k4:"<<k4;
        if(a[k1][j]==0)
            a[k1][j]=1;
        if(a[k2][j]==0)
            a[k2][j]=1;
        if(a[k3][j]==0)
            a[k3][j]=1;
        if(a[k4][j]==0)
            a[k4][j]=1;
    }
    void retrieve(char word[30])
    {
        int h1,h2,h3,h4,assocvalue,m[8]={0},k=0,t;
        float p=0;
        h1=hashone(word);
        h2=hashtwo(word);
        h3=hashthree(word);
        h4=hashfour(word);
    //   cout<<endl<<h1<<h2<<h3<<h4;
    //    cout<<endl;
        for(int j=0;j<8;j++)
        {   m[j]=a[h1][j]*a[h2][j]*a[h3][j]*a[h4][j];
            //cout<<a[h1][j]<<" "<<a[h2][j]<<" "<<a[h3][j]<<" "<<a[h4][j]<<" ";
          //  cout<<m[j]<<" ";
        }
        for(int i=0;i<8;i++)
        {   if(m[i]==1)
            {
                t=i;
                k++;
            }
        }
//        if(k>1)
//            cout<<"false positive";
//        if(k==0)
//            cout<<"word not in bloom";
        if(k>=1)
        {
            t=t+2;
            p=(t/8.0)/2;
            spam+=p;
            ham+=(1-p);
        }
        else
        {
            p=0.4;
            spam+=(1-p);
            ham+=p;
        }
//        for(int i=0;i<8;i++)
//            cout<<m[i]<<" ";
        //cout<<endl<<"p:"<<p;
       // cout<<endl<<"s:"<<spam<<" h:"<<ham;
    }

 }b;

void ParseEmailcontents()
{
    char filename[50];
    cout<<endl<<"Enter the filename::";
    cin>>filename;
    ifstream fin(filename);
    char ch[50];
    int i;
    if(!fin)
        cout<<"error";
    else
    {
        while(!fin.eof())
        {
            fin.getline(ch,50,' ');
            b.retrieve(ch);
            i++;
        }
    }
    cout<<endl<<"net spam:"<<spam;
    cout<<endl<<"net ham:"<<ham;
    if(spam>ham)
        cout<<endl<<"It is a SPAM!";
    else
        cout<<endl<<"It is a HAM";
}

main()
{
    char word[50],w[50],c,filename[50];
    int v=0,p=0,s=0,k=0,r1,r2,r3,i=0;
    float prob;
    b.init();
    ifstream fin("spamwords.txt");
    if(!fin)
        cout<<"error!";
    else
    {
        while(k!=100)
        {
            fin.getline(word,50,'#');
            puts(word);
            cout<<k;
            fin>>c;
            fin>>prob;
            b.insert(prob,word);
            k++;
            strcpy(word,"\0");
        }
    }
    fin.close();
    b.display();
    ParseEmailcontents();
}
