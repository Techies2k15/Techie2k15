//RESTAUREZIA - Nearby Hotel finder using  K - Dimensional Treap ... - Haja Mohideen and Shubashri

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include<string.h>
#include<stdio.h>
#include<fstream>

using namespace std;
 typedef struct Kd_Treap_node				
 {
     char key[20];				//The key here represents the name of the particular area in that dimension
     int priority;				//As we are using treaps we need priority value which balances the height of the tree randomly
     struct Kd_Treap_node* left;		// left child of the tree
     struct Kd_Treap_node* right;		// right child of  the tree
     struct Kd_Treap_node* next_dim;		// Pointer to the next dimension 
     char filename[200];			// Name of the file which contains the data of the hotels nearby that location
 }node;

 node* get_node(char key[20])			//Node allocation 
 {
     node* temp = new node;
     strcpy(temp->key,key);
     temp->priority =rand()%50;			//We are giving the priority as a random value such that expected height is O(log n) in a particular dimension
     temp->left = temp->right = NULL;
     temp->next_dim = NULL;
     strcpy(temp->filename,"NULL");
     return temp;
 }

 node* right_rotate(node* a )		//Normal avl right rotate
 {
     node* b = a->left;
     node* temp = b->right;
     b->right = a;
     a->left = temp;
     return b;

 }

 node* left_rotate(node* a) 		//Normal avl left rotate.
 {
    node* b = a->right;
    node* temp = b->left;
    b->left = a;
    a->right = temp;
    return b;

 }
 node* insert_node(node*,char key[][20],int,int,char*);

 node* insert_value(node* root,char key[][20],int dim,char rest[20]) // we are giving the path in that key array , dim represents the number of dimensions and rest is the name of the hotel
 {

     node* ptr = root;
     node* q = NULL;
     bool flag = 0;
     int tem_co = 0;
     int i;
     for(i = 0;i<dim;i++)
     {

        flag = 0;				// Searching the treap in the ith dimension for that location
        while(ptr != NULL)     
        {
            if(strcmp(ptr->key,key[i])==0)
            {

                flag = 1;
                break;
            }
            else if(strcmp(ptr->key,key[i])<0)
                ptr = ptr->right;
            else
                ptr = ptr->left;
        }
        if(flag)
        {
            tem_co++;			//tem_co represents the no of dimensions already exists for a given path. q gives the pointer to the previous dimension
            q = ptr;
            ptr = ptr->next_dim;	// If we find the existence of the ith place in the given path we move to next dimension

        }
        else
            break;			//we break the loop and insert the remaining path in our treap

     }
     if(tem_co == 0)			//This condition is required if none of the locations in that path exists so we are inserting everything and returning the pointer to root
     {
         root = insert_node(root,key,0,dim,rest); 
     }
     else if(tem_co==dim)		//if all the locations in that path already exists we just open the file and append our hotel name into it
     {
       
         char file[200];
         ofstream f;
         strcpy(file,key[0]);
     
         for(int k=1;k<dim;k++)
         {
             strcat(file,key[k]);
          
         }
         strcat(file,".txt");
         f.open(file,ios::app);
         if(strcmp(rest,"NULL")!=0)
            f<<rest<<"\n";
         f.close();
     }
     else if(tem_co<dim)	//if the no of locations in that path already exists is less than the given number of locations in the path we just insert the remaining locations
     {
 						    
         q->next_dim = insert_node(q->next_dim,key,tem_co,dim,rest);
     }
     return root;

 }
 node* insert_node (node* root, char key[][20],int st,int en,char rest[20])
 {							//st is the starting index of the location name that doesnt exist already and en is the no of dimensions			
     int i;
     char file[200];					// its similar to the normal treap insertion of a single dimension except we extended this concept for k dimensions
							
     if(!root)
     {

         node* temp = get_node(key[st]);
          node* ptr = temp;
         if(st == en-1)					//only at the last dimension we include the filename of the file which contains data of hotels nearby
         {
             ofstream f;
                 strcpy(file,key[0]);
              //   cout<<file<<endl;
                 for(int k=1;k<en;k++)
                {
                    strcat(file,key[k]);
                //    cout<<file<<endl;
                }
                strcat(file,".txt");
                f.open(file,ios::app);
                if(strcmp(rest,"NULL")!=0)
                    f<<rest<<"\n";
                f.close();
                strcpy(ptr->filename,file);


         }
         for(i = st+1;i<en;i++)
         {
             ptr->next_dim = get_node(key[i]);
             ptr = ptr->next_dim;
             if(i==en-1)
             {
                 ofstream f;
                 strcpy(file,key[0]);
              //   cout<<file<<endl;
                 for(int k=1;k<en;k++)
                {
                    strcat(file,key[k]);
                //    cout<<file<<endl;
                }
                strcat(file,".txt");
                f.open(file,ios::app);
                if(strcmp(rest,"NULL")!=0)
                    f<<rest<<"\n";
                f.close();
                strcpy(ptr->filename,file);

             }


         }
         ofstream of;
            char fil[200]={0};
            strcpy(fil,key[0]);
            strcat(fil,".");

            for(i=1;i<en;i++)
            {
                strcat(fil,key[i]);
                strcat(fil,".");
            }
            of.open("secondary.txt",ios::app);
            if(strcmp(rest,"NULL")!=0)
                of<<fil<<"\n";
            of.close();

         return temp;
     }
     if(strcmp(key[st],root->key)<0)
     {
         root->left = insert_node(root->left,key,st,en,rest);
         if(root->left->priority > root->priority)
         {
             root = right_rotate(root);
         }

     }
     else
     {
            root->right = insert_node(root->right,key,st,en,rest);
            if(root->right->priority > root->priority)
            {
                root = left_rotate(root);
            }
     }
     return root;
 }

void inorder(node*ptr) // Inorder traversal of a single dimension
{
    if(ptr==NULL)
        return;
    else
    {
        inorder(ptr->left);

        cout<<ptr->key<<endl;

        inorder(ptr->right);
    }

}

node* bstsearch(node* root,char newkey[20]) // Bst traversal of a single dimension 
{
    node*ptr=root;
    int flag=0;

    while(ptr!=NULL)
    {
        if(strcmp(ptr->key,newkey)==0)
        {
            cout<<endl<<"Found!"<<endl;
            flag=1;
            break;
        }

        else if(strcmp(newkey,ptr->key)<0)
        {
            ptr=ptr->left;
        }

        else
        {
            ptr=ptr->right;
        }
    }

    if(flag)
    {
        return ptr;
    }
}

void inorderkd1treap(node* root)  //K dimensional inorder traversal 
{
     char res[20];
     if(!root)
        return;
     else
     {
         inorderkd1treap(root->left); // After we move to the left child we then move to the dimension

         inorderkd1treap(root->next_dim);

         if(strcmp(root->filename,"NULL")!=0)  //Only the last dimensional nodes will have the filename not as null and we print all the data in that file 
         {

                ifstream f;
                f.open(root->filename,ios::in);

                f>>res;
                while(!f.eof())
                {
                    cout<<res<<endl;
                    f>>res;
                }
                f.close();
         }

         inorderkd1treap(root->right);
     }
 }

void search(node* root,char key[][20],int dim1,int dim) //This function just gives us all the nearby restaurants if there is no nearby restaurants for our given location
							//This will give us some suggestions to modify our search
{
     int i;
     node* ptr = root;
     node* q = NULL;
     node*parent=NULL;
     bool flag = 0;
     int tem_co = 0;

     if(dim1==dim)
     {
        for(i=0;i<dim1;i++)
        {

            flag = 0;
            while(ptr != NULL)
            {
                if(strcmp(ptr->key,key[i])==0)
                {

                    flag = 1;
                    break;
                }
                else if(strcmp(ptr->key,key[i])<0)
                {
                    parent=ptr;
                    ptr = ptr->right;
                }
                else
                {
                    parent=ptr;
                    ptr = ptr->left;
                }
            }
            if(flag)
            {
                tem_co++;
                q = ptr;
                ptr = ptr->next_dim;
            }
            else
                break;
        }
        if(tem_co==dim1)
        {
            cout<<endl<<"Restaurants Found!"<<endl;
            char file[200];
            char rest[30]={0};
            ifstream f;
            strcpy(file,key[0]);
            for(int k=1;k<dim;k++)
            {
                strcat(file,key[k]);
            }
            strcat(file,".txt");

            cout<<endl<<"Nearby restaurants : "<<endl;
            f.open(file,ios::in);
            if(f)
            {
                f>>rest;
                while(!f.eof())
                {
                    cout<<rest<<endl;
                    f>>rest;
                }

                f.close();
            }
            else
            {
                cout<<endl<<"Error"<<endl;
            }

        }
        else
        {
            //cout<<tem_co;
            char newkey[20];
            cout<<"Not found!"<<endl;
            cout<<"Nearby suggestions for searching : "<<endl;
            inorder(q->next_dim);
            cout<<"Enter any one among them : ";
            cin>>newkey;

            node* ptr=q->next_dim;
            node* k=bstsearch(q->next_dim,newkey);

            if(k->next_dim==NULL)
            {

                 char file[200];
                 char rest[30];

                 ifstream f;
                 strcpy(file,key[0]);
                 for(int k=1;k<dim-1;k++)
                 {
                     strcat(file,key[i]);
                 }
                 strcat(file,newkey);
                 strcat(file,".txt");
                 cout<<endl<<"Nearby Restaurants : "<<endl;
                 f.open(file,ios::in);
                 f>>rest;

                 while(!f.eof())
                 {
                     cout<<rest<<endl;
                     f>>rest;
                 }

                 f.close();
            }
            else
            {
                //cout<<k->next_dim->key;
                cout<<endl<<"Nearby Restaurants : "<<endl;
                inorderkd1treap(k->next_dim);
            }
        }
     }

     else if(dim1<dim)
     {
        ptr = root;
        q = NULL;
        parent=NULL;
        flag = 0;
        tem_co = 0;

        for(i=0;i<dim1;i++)
        {

            flag = 0;
            while(ptr != NULL)
            {
                if(strcmp(ptr->key,key[i])==0)
                {

                    flag = 1;
                    break;
                }
                else if(strcmp(ptr->key,key[i])<0)
                {
                    parent=ptr;
                    ptr = ptr->right;
                }
                else
                {
                    parent=ptr;
                    ptr = ptr->left;
                }
            }
            if(flag)
            {
                tem_co++;
                q = ptr;
                ptr = ptr->next_dim;
            }
            else
                break;
        }
        if(tem_co==dim1)
        {
            cout<<endl<<"Restaurants Found!"<<endl<<endl;
            inorderkd1treap(ptr);
        }

        else
        {
            //cout<<tem_co;
            char newkey[20];
            cout<<endl<<"Not found!"<<endl;
            cout<<endl<<"Nearby suggestions for searching : "<<endl;
            inorder(q->next_dim);
            cout<<endl<<"Enter any one among them : ";
            cin>>newkey;

            node* ptr=q->next_dim;
            node* k=bstsearch(q->next_dim,newkey);
            cout<<endl<<"Nearby Restaurants :"<<endl;
            inorderkd1treap(k->next_dim);
        }
     }
     else
     {
         cout<<endl<<"Invalid path address!"<<endl;
     }
    return;
}

node* remove_node(node* ,char*);

node* remove_value(node* root, char key[][20],int st,int en,char rest[])
{								//This function is used to remove a restaurant in our database 
    node* ptr = root;						//This function also deletes the paths in which no restaurants exists																
    int i;
    if(root == NULL)
    {
        cout<<"Restaurant not found ";
        return root;
    }
    else
    {
        while(ptr)
        {
            if(strcmp(ptr->key,key[st])==0)
            {
                if(!ptr->next_dim && st != en-1)
                {
                    cout<<"Restaurant not found";
                    return root;
                }
                else if(st == en-1)
                {
                        bool flag = 0;
                        char str[20][20]={{0}};
                        ifstream f;
                        char file[200];
                        char a[20];

                        strcpy(file,key[0]);
                        for(int k=1;k<en;k++)
                        {
                            strcat(file,key[k]);
                        }
                        strcat(file,".txt");

                        f.open(file,ios::in);

                        f>>a;
                        int i=0;
                        while(!f.eof())
                        {
                            strcpy(str[i],a);
                            i++;
                            f>>a;
                        }

                        f.close();

                        ofstream f1;
                        f1.open(file,ios::out);
                        for(int k=0;k<i;k++)
                        {
                            if(strcmp(rest,str[k])!=0)
                                f1<<str[k]<<'\n';
                            else
                            {
                                flag = 1;
                                i = i-1;
                            }

                        }
                        if(!flag)
                        {
                            cout<<"Restaurant not found ";
                        }
                        f1.close();
                        if(i == 0)
                        {
                            char a[200];
                            root = remove_node(root,key[st]);
                            remove(file);
                            ifstream f3;
                            ofstream f4;
                            f4.open("temp.txt",ios::out);
                            f3.open("secondary.txt");

                            char fil[200]={0};
                            strcpy(fil,key[0]);
                            strcat(fil,".");

                            for(i=1;i<en;i++)
                            {
                                strcat(fil,key[i]);
                                strcat(fil,".");
                            }
                            f3>>a;

                            while(!f3.eof())
                            {
                                if(strcmp(a,fil)!=0)
                                {
                                    f4<<a<<'\n';
                                }
                                f3>>a;

                            }
                            f3.close();
                            f4.close();

                            remove("secondary.txt");
                            rename("temp.txt","secondary.txt");
                        }

                    return root;
                }
                else if(st < en)
                {
                    ptr->next_dim = remove_value(ptr->next_dim,key,st+1,en,rest);
                    if(ptr->next_dim == NULL)
                    {
                        root = remove_node(root,key[st]);
                        return root;
                    }
                    return root;


                }
            }
            else if(strcmp(key[st],ptr->key)<0)
            {
                ptr = ptr->left;
            }
            else
                ptr = ptr->right;
        }
    }
    if(!ptr)
    {
         cout<<"Restaurant not found";
         return root;
    }


}
node* remove_node(node*root , char key[20])	//This function is used to remove a location in a given dimension
{
    if(root == NULL)
        return root;
    else if(strcmp(key,root->key)<0)
    {
        root->left = remove_node(root->left,key);

    }
    else if(strcmp(key,root->key)>0)
        root->right = remove_node(root->right,key);
    else if(root->left == NULL)
    {
        node* temp = root->right;
        delete root;
        root = temp;
    }
    else if(root->right == NULL)
    {
        node* temp = root->left;
        delete root;
        root = temp;

    }
    else if(root->left->priority < root->right->priority)
    {
        root = left_rotate(root);
        root->left = remove_node(root->left,key);

    }
    else
    {
        root = right_rotate(root);
        root->right = remove_node(root->right,key);

    }
    return root;
 }

 void inorder_treap(node* root)
 {
     if(!root)
        return;
     else
     {
         inorder_treap(root->left);
         cout<<root->key<<"(";
         inorder_treap(root->next_dim);
         cout<<"),";

         inorder_treap(root->right);
     }
 }

int main()
{
    char key[50][20]={0};
    char rest[20];
    char filenam[200];
    int dim,op;
    int i;
    char c;

    srand(time(NULL));
    node* root = NULL;
    cout<<"Enter the no. of dimensions in the path address :";
    cin>>dim;

    ifstream if1;

    if1.open("secondary.txt");
    if(if1)
    {
        if1>>filenam;
        while(!if1.eof())
        {
            char * pch;
            i=0;
            pch = strtok (filenam,".");
            while (pch != NULL)
            {
                strcpy(key[i],pch);
                i++;
                //cout<<pch<<endl;
                pch = strtok (NULL, ".");
            }
            strcpy(rest,"NULL");
            root = insert_value(root,key,dim,rest);
            if1>>filenam;
        }
        if1.close();
        cout<<endl<<"Successfully loaded data!"<<endl;
    }

    do
    {
        system("cls");
        cout<<"\t\t  RESTAUREZIA"<<endl<<endl;
        cout<<"\t\t  OPTIONS :"<<endl<<endl;
        cout<<"\t1.Create new restaurants"<<endl;
        cout<<"\t2.Want to search...."<<endl;
        cout<<"\t3.Destruct restaurants"<<endl;
        cout<<"\t4.Exit app."<<endl<<endl;

        cout<<"Your option : ";
        cin>>op;

        if(op==1)
        {
            cout<<"Enter the path address :";
            for(i =0;i<dim;i++)
            {
                cin>>key[i];

            }
            cout<<"Enter restaurant :";
            cin>>rest;

            root = insert_value(root,key,dim,rest);
            //cout<<"root - ---"<<root->key;
            cout<<endl<<"Successfully inserted!"<<endl;
        }
        else if(op==2)
        {
            int dim1;
            cout<<"Enter no. of dimensions of the path address :";
            cin>>dim1;
            cout<<"Enter path address : ";

            for(i =0;i<dim1;i++)
            {
                cin>>key[i];
            }
            search(root,key,dim1,dim);
        }
        else if(op==3)
        {
            char rest[20]={0};
            cout<<"Enter the path address to be deleted";
            for(i = 0;i<dim ; i++)
            {
                cin>>key[i];
            }
            cout<<"Enter restaurant : ";
            cin>>rest;
            root = remove_value(root,key,0,dim,rest);
        }
        else if(op==4)
        {
            exit(0);
        }
        else
        cout<<endl<<"Invalid option!"<<endl<<endl;

        cout<<endl<<"Do u want to continue (y/n) ??";
        cin>>c;
    }while(c=='y');
}
