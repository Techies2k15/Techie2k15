import sys
import os
import datetime
from pprint import pprint
from flights import *
from pprint import pprint
from random import randint
from math import radians, cos, sin, asin, sqrt

class City:
    def __init__(self,a,b,c):
        self.id = a
        self.lat = float(b)
        self.lon = float(c)
        self.adjacent = {}
        # Set distance to infinity for all nodes
        self.distance = sys.maxsize
        # Mark all nodes unvisited        
        self.visited = False  
        # Predecessor
        self.previous = None

    def addNeighbor(self, neighbor, weight=0):
        self.adjacent[neighbor] = weight

    def getConnections(self):
        return self.adjacent.keys()  

    def getId(self):
        return self.id

    def getCost(self,city):
        cost = sys.maxsize
        for flt in Flights:
            if self.id == flt.source and city.id == flt.dest:
                if flt.dist<cost:
                    cost = flt.dist
        return cost

    def getWeight(self, neighbor):
        return self.adjacent[neighbor]

    def setDistance(self, dist):
        self.distance = dist

    def getDistance(self):
        return self.distance

    def setPrevious(self, prev):
        self.previous = prev

    def setVisited(self):
        self.visited = True

    def __str__(self):
        return str(self.id) + ' adjacent: ' + str([x.id for x in self.adjacent])

class Graph:
    def __init__(self):
        self.adjList = {}
        self.num_vertices = 0

    def __iter__(self):
        return iter(self.adjList.values())

    def addCity(self,name,lat,lon):
        new_vertex = City(name,lat,lon)
        if name in self.adjList.keys():
            return False
        self.num_vertices = self.num_vertices + 1
        self.adjList[name] = new_vertex
        return new_vertex

    def getCity(self, n):
        if n in self.adjList:
            return self.adjList[n]
        else:
            return None

    def addAirConnection(self, frm, to, cost = 0):
        cost = self.adjList[frm].getCost(self.adjList[to])
        self.adjList[frm].addNeighbor(self.adjList[to], cost)
        #self.adjList[to].addNeighbor(self.adjList[frm], cost)

    def getCities(self):
        return self.adjList.keys()

    def setPrevious(self, current):
        self.previous = current

    def getPrevious(self, current):
        return self.previous

    def displayGraph(self):
        print 'Graph data:'
        cnt = 0
        for v in self.adjList.keys():
            adj = []
            src = v
            v = self.getCity(src)
            for w in v.getConnections():
                adj.append(w.getId())
            #print '%s %s %3d'  % ( vid, wid, v.getWeight(w))
            if adj:
                cnt +=1
                print src+" "+str(adj)
        print cnt
    def reloadGraph(self):
        for city in self.adjList.values():
            city.distance = sys.maxint       
            city.visited = False  
            city.previous = None

def dist(S,D):
    lat1 = S.lat
    lon1 = S.lon
    lat2 = D.lat
    lon2 = D.lon 
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2]) 
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a)) 
    km = 6367 * c
    return int(km)

def generatePrice(flt):
    return flt.dist*randint(5,20)

def timeConvert(miliTime):
    hours = int(miliTime[:2])
    minutes = int(miliTime[2:])
    setting = "AM"
    if hours > 12:
        setting = "PM"
        hours -= 12
    elif hours == 12:
        if minutes>0:
            setting = "PM"
    return ("%02d:%02d" + setting) %(hours, minutes)

def getDur(start,end):
    start_t = datetime.time(hour=int(start[0:2]), minute=int(start[2:4]))
    end_t = datetime.time(hour=int(end[0:2]), minute=int(end[2:4]))
    delta_t = datetime.timedelta(
        hours = (end_t.hour - start_t.hour),
        minutes = (end_t.minute - start_t.minute)
    )
    hrs,mins,secs = str(delta_t).split(":")
    if len(hrs)>2:
        hrs = hrs[-2:]
    res = str(int(hrs))+":"+mins
    #print "%s,%s,%s" %(hrs,mins,secs)
    return res
    
def printFlight(flt):
    print (flt.airline+" "+flt.source+" "+flt.dest+" "+flt.flight+" "+timeConvert(flt.depart)+" "+timeConvert(flt.arrive)+" "+flt.freq+" "+str(flt.dist)+"km "+flt.dur+" Rs."+str(flt.price))

def searchFlight(S,D):
    cost = sys.maxint
    flight = None
    print ("\nAvailable Flights "+S.upper()+" - "+D.upper())
    for flt in Flights:
        if S == flt.source and D == flt.dest:
            printFlight(flt)
            if flt.price<cost:
                cost = flt.price
                flight = flt
    print ("Cheapest Flight:")
    if flight:
        printFlight(flight)
    else:
        print "\n NO FLIGHTS AVAILABLE"
    return flight            

def shortest(v, path):
    if v.previous:
        path.append(v.previous.getId())
        shortest(v.previous, path)
    return

import heapq

def dijkstra(aGraph, start, target):
    print ("Calculating Dijkstra's shortest path...")
    # Set the distance for the start node to zero 
    start.setDistance(0)
    # Put tuple pair into the priority queue
    unvisited_queue = [(v.getDistance(),v) for v in aGraph]
    heapq.heapify(unvisited_queue)
    while len(unvisited_queue):
        # Pops a City with the smallest distance 
        uv = heapq.heappop(unvisited_queue)
        current = uv[1]
        current.setVisited()
        #for next in v.adjacent:
        for next in current.adjacent:
            # if visited, skip
            if next.visited:
                continue
            new_dist = current.getDistance() + current.getWeight(next)
            if new_dist < next.getDistance():
                next.setDistance(new_dist)
                next.setPrevious(current)
                #print 'updated : current = %s next = %s new_dist = %s' \
                 #       %(current.getId(), next.getId(), next.getDistance())
            else:
                pass
                #print 'not updated : current = %s next = %s new_dist = %s' \
                #        %(current.getId(), next.getId(), next.getDistance())
        # Rebuild heap
        # 1. Pop every item
        while len(unvisited_queue):
            heapq.heappop(unvisited_queue)
        # 2. Put all vertices not visited into the queue
        unvisited_queue = [(v.getDistance(),v) for v in aGraph if not v.visited]
        heapq.heapify(unvisited_queue)

def shortestPath(g,src,dest,retFlag=True):
    if retFlag:
        print ("\nOnward Journey")
    dijkstra(g, g.getCity(src), g.getCity(dest)) 
    target = g.getCity(dest)
    path = [target.getId()]
    shortest(target, path)
    path = path[::-1]
    #print len(path)
    if len(path) == 1:
        print "NO FLIGHTS AVAILABLE"
        return False
    print ('The shortest path : %s' %(path))
    #print "\nBest flights to take:"
    cur = path[0]
    fare = 0
    best = []
    for nxt in path[1:]:
        flight = searchFlight(cur,nxt)
        fare += flight.price
        best.append(flight)
        #printFlight(flight)
        cur = nxt
    tTime = datetime.timedelta()
    for flt in best:
        t = flt.dur+":00"
        (h, m, s) = t.split(':')
        d = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))
        tTime += d
    tTime = str(tTime)[:len(str(tTime))-3]
    hr,mi= tTime.split(':')
    tTime = hr+"h "+mi+"min"
    print ("\nBest flights to take:")
    [printFlight(flt) for flt in best]
    print ("\nTotal distance: "+str(target.distance)+"km")
    print ("Total travel time: "+tTime)
    #print "Total duration: "+getDur(best[0].depart,best[len(best)-1].arrive)
    print ("Total fare: Rs."+str(fare))
    g.reloadGraph()
    if retFlag:
        print ("\nReturn Journey")
        shortestPath(g,dest,src,retFlag=False)
    
Map = Graph()

f = open("locations.txt")
data = f.read()
f.close()

L = data.split()
Locs = []
Lats = []
Lons = []

for i in range(len(L)):
    if i%3 == 0:
        Locs.append(L[i])
    elif i%3 == 1:
        Lats.append(L[i])
    else:
        Lons.append(L[i])

Coords = zip(Lats,Lons)
Data = dict(zip(Locs,Coords))

for city,coord in Data.items():
    Map.addCity(city,coord[0],coord[1])

for route in Flights:
    if route.source in Locs and route.dest in Locs:
        route.dist = dist(Map.adjList[route.source],Map.adjList[route.dest])
        route.price = generatePrice(route)
        route.dur = getDur(route.depart,route.arrive)
    Map.addAirConnection(route.source,route.dest)

#shortestPath(Map,"Mumbai","Delhi")

while True:
    print "\n" * 50
    print "\t\t\t\t\t\t\t\tFLIGHT BUDDY\n"
    print "Choose one of the options: "
    print "1. Best route"
    print "2. Search flights"
    print "3. Display adjacency list"
    print "4. Display flights"
    print "5. Exit"
    ch = raw_input(">>> ")
    #os.system('cls')
    print "\n" * 50
    if ch == '5':
        sys.exit(1)
    elif ch == '1':
        source = raw_input("Source: ").title()
        dest = raw_input("Destination: ").title()
        roundTrip = raw_input("Round trip?(Y/N): ")
        roundTrip = True if roundTrip.upper()=="Y" else False
        if source in Locs and dest in Locs:
            shortestPath(Map,source,dest,roundTrip)
        else:
            print "\nNO FLIGHTS AVAILABLE"
    elif ch == '2':
        src = raw_input("Source: ").title()
        dst = raw_input("Destination: ").title()
        if src in Locs and dst in Locs:
            searchFlight(src,dst)
        else:
            print "\nNO FLIGHTS AVAILABLE"
    elif ch == '3':
        Map.displayGraph()
    elif ch == '4':
        cnt = 0
        for flight in Flights:
            cnt+=1
            printFlight(flight)
        print cnt
    else:
        print "\nINVALID INPUT"
    ch = raw_input("\nEnter any key to continue...")
    os.system('cls')
 
