from random import randint
class Flight:
    def __init__(self,air,src,dest,fno,freq,dtim,atim):
        self.airline = air
        self.source = src
        self.dest = dest
        self.dur = ""
        self.flight = fno
        self.depart = dtim
        self.arrive = atim
        self.freq = freq
        self.dist = 0
        self.price = 0

def changeFreq(freq):
    if freq == "Daily":
        return "M|T|W|Th|F|S|Su"
    Days = ["M","T","W","Th","F","S","Su"]
    freq = list(freq)
    F = ""
    for i in freq:
        F+=Days[int(i)-1]+"|"
    return F[:len(F)-1]

def getFlightData(fname,air):
    fptr = open(fname)
    #data = fptr.read()
    for line in fptr:
        #print line
        line = line.split()
        if len(line[0])<=2:
            src = line[1].title()
        else:
            dest = line[0].title()
            if line[1][0] == '(':
                fno = line[3]+"-"+line[4]
                freq = changeFreq(line[6])
                dtim = line[7]
                atim = line[8]
            else:
                fno = line[2]+"-"+line[3]
                freq = changeFreq(line[5])
                dtim = line[6]
                atim = line[7]
            Flights.append(Flight(air,src,dest,fno,freq,dtim,atim))        
    fptr.close()

Flights = []
getFlightData("airIndia.txt","AI")
getFlightData("jetAirways.txt","JA")
getFlightData("spiceJet.txt","SJ")
#for flight in Flights:
 #   print flight.airline+" "+flight.source+" "+flight.dest+" "+flight.flight+" "+flight.freq+" "+str(flight.depart)+" "+str(flight.arrive)+" "+str(flight.price)
