# FlyBuddy

FlyBuddy is a realworld-data driven Indian domestic flight route mapper which uses real world flight data from three airlines and can 
be used to find the shortest and cheapest air routes between two cities of India.

Open flightBuddy.py

By
15PT05 Aravindha Prasath S, 15PT06 Benjamin B Beeshma, 15PT34 Sudharshan S
