#include<iostream>
#include<string>
#include<sstream>
#include<stdlib.h>
#include<math.h>
using namespace std;

int i=0;
int j=0;
struct source
{
    string f;
    string sp;
    string lb;
    string ub;
    int start;
    int finish;
};
source *a=new source[10];
source *b=new source[10];
typedef struct node
{
    int key;
    string filter[6];
    int cnt;
    struct node *left;
    struct node *right;
}node;
node *root1=NULL,*root2=NULL;

class ip
{
  public:
      string printlevel(struct node *, int, string);
      void printLevelOrder (struct node* , int );
      void src();
      void des();
      int bin2dec(string);
      void display1();
      void display2();
      struct node* newNode(int,string);
      struct node* rightRotate(struct node*);
      struct node* leftRotate(struct node* );
      struct node* splay(struct node*,int);
      struct node* insert(struct node*,int,string);
      void displaytree(struct node*,int);
      void adjust1(struct node*);
      void adjust2(struct node*);
      void inOrder1(struct node *);
      void inOrder2(struct node *);
      void inOrder (struct node*);

};
void ip::src()
{
    string f;
    string s;
    cout<<"enter a value of filter";
    cin>>f;
    cout<<"enter its source prefix";
    cin>>s;
    a[i].f=f;
    a[i].sp=s;

    a[i].sp=(a[i].sp).substr(0,(a[i].sp).length()-1);

    if((a[i].sp).length()==0)
    {
        a[i].lb="000000";
        a[i].ub="111111";
    }
    else if((a[i].sp).length()==1)
    {
        a[i].lb=a[i].sp+"00000";
        a[i].ub=a[i].sp+"11111";
    }
    else if((a[i].sp).length()==2)
    {
        a[i].lb=a[i].sp+"0000";
        a[i].ub=a[i].sp+"1111";
    }
    else if((a[i].sp).length()==3)
    {
        a[i].lb=a[i].sp+"000";
        a[i].ub=a[i].sp+"111";
    }
    else if((a[i].sp).length()==4)
    {
        a[i].lb=a[i].sp+"00";
        a[i].ub=a[i].sp+"11";
    }
    else if((a[i].sp).length()==5)
    {
        a[i].lb=a[i].sp+"0";
        a[i].ub=a[i].sp+"1";
    }
    else if((a[i].sp).length()==6)
    {
        a[i].lb=a[i].sp;
        a[i].ub=a[i].sp;
    }
    else
    {
        cout<<"invalid";
    }
    a[i].start=bin2dec(a[i].lb);
    a[i].finish=bin2dec(a[i].ub);
    i++;
    display1();
}
void ip::des()
{
    string f;
    string s;
    cout<<"enter a value of filter for destintion table";
    cin>>f;
    cout<<"enter its source prefix for destination table";
    cin>>s;
    b[j].f=f;
    b[j].sp=s;

    b[j].sp=(b[j].sp).substr(0,(b[j].sp).length()-1);

    if((b[j].sp).length()==0)
    {
        b[j].lb="000000";
        b[j].ub="111111";
    }
    else if((b[j].sp).length()==1)
    {
        b[j].lb=b[j].sp+"00000";
        b[j].ub=b[j].sp+"11111";
    }
    else if((b[j].sp).length()==2)
    {
        b[j].lb=b[j].sp+"0000";
        b[j].ub=b[j].sp+"1111";
    }
    else if((b[j].sp).length()==3)
    {
        b[j].lb=b[j].sp+"000";
        b[j].ub=b[j].sp+"111";
    }
    else if((b[j].sp).length()==4)
    {
        b[j].lb=b[j].sp+"00";
        b[j].ub=b[j].sp+"11";
    }
    else if((b[j].sp).length()==5)
    {
        b[j].lb=b[j].sp+"0";
        b[j].ub=b[j].sp+"1";
    }
    else if((b[j].sp).length()==6)
    {
        b[j].lb=b[j].sp;
        b[j].ub=b[j].sp;
    }
    else
    {
        cout<<"invalid";
    }
    b[j].start=bin2dec(b[j].lb);
    b[j].finish=bin2dec(b[j].ub);
    j++;
    display2();
}

int ip::bin2dec(string bin)
{
    int value;
    stringstream(bin)>>value;
    int dec=0,rem=0;
    int base=1;
    int num=0;
    num=value;
    while(num>0)
    {
        rem=num%10;
        dec=dec+(rem*base);
        base =base*2;
        num=num/10;
    }
    return dec;
}

void ip::display1()
{
    cout<<"filter"<<"\t"<<"prefix"<<"\t lb"<<"\t ub"<<"\t start"<<"\t finish";
    for(int k=0;k<i;k++)
    {
     cout<<"\n "<<a[k].f<<"\t"<<a[k].sp<<"\t"<< a[k].lb<<"\t"<< a[k].ub<<"\t"<< a[k].start<<"\t"<< a[k].finish<<"\n";
    }
}

void ip::display2()
{
    cout<<"filter"<<"\t"<<"prefix"<<"\t lb"<<"\t ub"<<"\t start"<<"\t finish";
    for(int k=0;k<j;k++)
    {
     cout<<"\n "<<b[k].f<<"\t"<<b[k].sp<<"\t"<< b[k].lb<<"\t"<< b[k].ub<<"\t"<< b[k].start<<"\t"<< b[k].finish<<"\n";
    }
}

struct node* ip::newNode(int key,string f)
{
    struct node* Node =new node;
    Node->key= key;
    Node->cnt=1;
    Node->filter[0]=f;
    Node->left= Node->right  = NULL;
    return (Node);
}

struct node* ip::insert(struct node *root, int k,string f)
{
    if (root == NULL)
    {
        return newNode(k,f);
    }
    root = splay(root, k);
    if (root->key == k)
    {
        root->cnt++;
        root->filter[(root->cnt)-1]=f;
        return root;
    }
    struct node *newnode  = newNode(k,f);
    if (root->key > k)
    {
        newnode->right = root;
        newnode->left = root->left;
        root->left = NULL;
        newnode->cnt=1;
        newnode->filter[0]=f;
    }
    else
    {
        newnode->left = root;
        newnode->right = root->right;
        root->right = NULL;
        newnode->cnt=1;
        newnode->filter[0]=f;
    }
    return newnode;
}

struct node* ip::rightRotate(struct node *x)
{
    struct node *y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}
struct node* ip::leftRotate(struct node *x)
{
    struct node *y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}
struct node* ip::splay(struct node *root, int key)
{
    if (root == NULL || root->key == key)
    {
        return root;
    }
    if (root->key > key)
    {
        if (root->left == NULL)
            return root;
        if (root->left->key > key)
        {
            root->left->left = splay(root->left->left, key);
            root = rightRotate(root);
        }
        else if (root->left->key < key)
        {
            root->left->right = splay(root->left->right, key);
            if (root->left->right != NULL)
            root->left = leftRotate(root->left);
        }
        return (root->left == NULL)? root: rightRotate(root);
    }
    else
    {
        if (root->right == NULL)
            return root;
        if (root->right->key > key)
        {
            root->right->left = splay(root->right->left, key);
            if (root->right->left != NULL)
                root->right = rightRotate(root->right);
        }
        else if (root->right->key < key)
        {
            root->right->right = splay(root->right->right, key);
            root = leftRotate(root);
        }
        return (root->right == NULL)? root: leftRotate(root);
    }
}
void ip::printLevelOrder (struct node* root, int depth)
{
  for (int i=1; i<=depth; i++)
  {
    string gap="";
    for (int j=0; j<pow(2,depth-i)-1; j++)
    {
      gap+=" ";
    }
    string levelNodes = printlevel(root, i, gap);
    cout<<levelNodes<<endl;
  }
}
string ip::printlevel(struct node *root, int level, string gap)
{
  if (!root)
    {
    return gap + " " + gap;
    }
  if (level==1)
  {
    stringstream out;
    out<<root->key;
    return gap + out.str() + gap;
  }
  else if (level>1)
    {
    string leftStr = printlevel(root->left, level-1, gap);
    string rightStr = printlevel(root->right, level-1, gap);
    return leftStr + " " + rightStr;
    }
  else return " ";
}

void ip::inOrder1(struct node *root)
{
    if (root != NULL)
    {
        inOrder1(root->left);
        adjust1(root);
        inOrder1(root->right);
    }
}

void ip::adjust1(struct node* root)
{
    int x=0;
     while(x<i)
        {
         if((root->key>a[x].start)&&(root->key<a[x].finish))
        {
            root->cnt++;
            root->filter[(root->cnt)-1]=a[x].f;
        }
        x++;
        }
        cout<<root->key<<"\n";
        cout<<"the filters are"<<endl;
        for(int j=0;j<root->cnt;j++)
        {
            cout<<root->filter[j]<<"\n";
        }
        cout<<"\n";
}
void ip::inOrder2(struct node *root)
{
    if (root != NULL)
    {
    	inOrder2(root->left);
       adjust2(root);
       inOrder2(root->right);
    }
}
void ip::adjust2(struct node* root)
{
    int y=0;
     while(y<j)
        {
         if((root->key>b[y].start)&&(root->key<b[y].finish))
        {
            root->cnt++;
            root->filter[(root->cnt)-1]=b[y].f;
        }
        y++;
        }
        cout<<root->key<<"\n";
        cout<<"the filters are"<<endl;
        for(int m=0;m<root->cnt;m++)
        {
            cout<<root->filter[m]<<"\n";
        }
        cout<<"\n";

}
int main()
{
    ip i1;
    int l;
    int w;
    struct node* temp;
    struct node* temp1;
    while(1)
    {
    cout<<"enter your choice\n";
    cout<<"1.enter for source table\n";
    cout<<"2.enter for destination table\n";
    cout<<"3.source tree\n";
    cout<<"4.destination tree\n";
    cout<<"enter ur choice"<<endl;
    cin>>w;
    switch(w)
    {
    case 1:
        i1.src();
        break;
    case 2:
        i1.des();
        break;
    case 3:
        for(l=0;l<i;l++)
        {
            root1=i1.insert(root1,a[l].start,a[l].f);
            root1=i1.insert(root1,a[l].finish," ");
        }
        temp=root1;
        i1.inOrder1(temp);
        temp=root1;
        i1.printLevelOrder(temp,5);
        break;
    case 4:
        for(l=0;l<j;l++)
        {
            root2=i1.insert(root2,b[l].start,b[l].f);
            root2=i1.insert(root2,b[l].finish," ");
        }
        temp1=root2;
        i1.inOrder2(temp1);
        temp1=root2;
        i1.printLevelOrder(temp1,6);
        break;
    }
    }
}
