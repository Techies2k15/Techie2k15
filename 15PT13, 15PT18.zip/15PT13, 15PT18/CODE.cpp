#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<fstream>
#include<string.h>

using namespace std;
typedef struct b_tree
{

    int nok,freq[10];
    bool leaf;
    char k[10][20];
    struct b_tree **c;
}node;

int m=11;
int t =6;
node* allocate_node()
{
    int i;
    char a[2];
    a[0]='\0';
    node* temp = new node;
    //temp->k=new int[m-1];
    temp->c=new node *[m];
    for(i=0;i<m;i++)
    {
        temp->c[i] = NULL;
    }
    for(i = 0 ;i<m-1 ;i++)
    {
        strcpy(temp->k[i],a);
        temp->freq[i]=0;
    }

    temp->nok = 0;
    return temp;
}
node* b_tree_create()
{
    node* x = allocate_node();

    x->leaf = 1;
    x->nok = 0;
    return x;
}
int insert_search(node *&x,char k[])
{
    if(x==NULL)
        return -1;
    else
    {
        int i=0;
        while(i<= x->nok-1  &&  strcmp(k,x->k[i]) >0)
        {
            i=i+1;
        }
        if(i<=x->nok-1 && strcmp(k,x->k[i])==0)
        {

            x->freq[i]++;
            if(x->freq[i]>30)
                x->freq[i]=x->freq[i] /30
                ;
            return 0;
        }

        else if(x->leaf)
            return -1;
        else
            return insert_search(x->c[i],k);
    }
}
void b_tree_split(node*,int,node*);
void b_tree_nonfull(node*x,char *k);
void b_tree_insert(node *&root,char k[])
{
    int flag;
    flag=insert_search(root,k);
    if(flag== -1)
    {

    node *r=root;
    if(r->nok==10)
    {
        node *s=allocate_node();
        root=s;
        s->nok=0;
        s->leaf=0;
        s->c[0]=r;
        b_tree_split(s,0,r);
        b_tree_nonfull(s,k);
    }
    else
        b_tree_nonfull(r,k);
    }
}

void b_tree_nonfull(node *x,char k[])
{
    int i,j;
    i=x->nok-1;
    j=0;

    if(x->leaf)
    {
        while(i>=0 && (strcmp(k,x->k[i]) <0))
        {
            strcpy(x->k[i+1],x->k[i]);
            x->freq[i+1]=x->freq[i];
            i--;
        }
        strcpy(x->k[i+1],k);
        x->freq[i+1]=1;
        x->nok++;
    }

    else
    {
            while(i>=0 && (strcmp(k,x->k[i])<0))
            {
                i=i-1;
            }
            i=i+1;
            if(x->c[i]->nok==10)
            {
                b_tree_split(x,i,x->c[i]);
                if(strcmp(k,x->k[i])>0)
                    i++;
            }
            b_tree_nonfull(x->c[i],k);
    }
}



void b_tree_split(node *x,int i,node *y)
{   int j,n;
    node *z=allocate_node();
    z->leaf=y->leaf;
    z->nok=t-2;
    for(j=0;j<t-2;j++)
    {
        strcpy(z->k[j],y->k[j+t]);
        z->freq[j]=y->freq[j+t];
    }
    if(!y->leaf)
    {
        for(j=0;j<t-1;j++)
        {
            z->c[j]=y->c[j+t];
        }
    }
    n=x->nok;
    for(j=x->nok;j>=i+1;j--)
    {
        x->c[j+1]=x->c[j];
    }


    y->nok=t-1;
    x->c[i+1]=z;
    for(j=x->nok-1;j>=i;j--)
    {
        strcpy(x->k[j+1],x->k[j]);
        x->freq[j+1]=x->freq[j];
    }
    strcpy(x->k[i],y->k[t-1]);
    x->freq[i]=y->freq[t-1];
    x->nok++;
}


void traverse(node *p)
{

    int i;
    for (i = 0; i < p->nok; i++)
    {
        if (p->leaf == false)
        {
            traverse(p->c[i]);
        }
        cout << p->k[i]<<" "<<p->freq[i]<<endl;
    }
    if (p->leaf == false)
    {
        traverse(p->c[i]);
    }

}
void inorder(node* ptr)
{
    //cout<<"hai";
    int i;
    if(ptr==NULL)
    {
        cout<<"no tree";
    }
    else
    {
        for(i = 0; i < ptr->nok+1 ;i++)
        {
            if(ptr->c[i])
                inorder(ptr->c[i]);
            if(i<10 && i<ptr->nok)
                cout<< ptr->k[i]<<" "<<ptr->freq[i]<<endl;
        }
    }
}
int freqcount(node *&x,char k[])
{
        if(x==NULL)
        return -1;
    else
    {
        int i=0;
        while(i<= x->nok-1  &&  strcmp(k,x->k[i]) >0)
        {
            i=i+1;
        }
        if(i<=x->nok-1 && strcmp(k,x->k[i])==0)
        {

            return x->freq[i];

        }

        else if(x->leaf)
            return -1;
        else
            return freqcount(x->c[i],k);
    }
}

int  calresult(node* &x,node *&y)
{
     int i,sum=0,n;
        for(i = 0; i < x->nok+1 ;i++)
        {
            if(x->c[i])
                calresult(x->c[i],y);
            if(i<10 && i<x->nok)

            {
                n=freqcount(y,x->k[i]);
                if(n!= -1)
                {//cout<<"i"<<n<<endl;
                    sum=sum+ ((n *10)- x->freq[i]);
                   // cout<<sum;
                }
                else

                    sum=sum+0;
            }

        }


    return sum;


}

int wordlookup(node *&x,char k[])
{
    if(x==NULL)
        return -1;
    else
    {
        int i=0;


        while(i<= x->nok-1  &&  strcmp(k,x->k[i]) >0)
        {
            i=i+1;
        }
        if(i<=x->nok-1 && strcmp(k,x->k[i])==0)
        {
            return 0;
        }

        else if(x->leaf)
            return -1;
        else
            return wordlookup(x->c[i],k);
    }
}
char* stemming(char word[])
{
    int i,j;
    for(i=0;i<strlen(word);i++)
    {
        word[i]=tolower(word[i]);
    }
    for(i=0;word[i]!='\0';i++)
    {
        if(word[i]=='.' || word[i]=='-' || word[i]== '~' || word[i]=='*' || word[i]=='`' || word[i]==',' || word[i]=='<' || word[i]=='>' || word[i]=='?' || word[i]==';' || word[i]==':' || word[i]=='"' || word[i]=='}' || word[i]=='{' || word[i]=='(' || word[i]==')' || word[i]=='[' ||word[i]==']' || word[i]=='!')
        {

            for(j=i;j<strlen(word);j++)
            {
                word[j]=word[j+1];
            }
            --i;

        }
    }

    return word;
}
int main()
{
    int noq,n,x,y,i,j=-1,k=-1,l=-1,flag=0,tot[50];
    char word[30],file[30],fileword[30],ch[2],query[100],result[50][20],c;
    node* root = NULL;
    node* stop_tree=NULL;
    node* query_tree=NULL;
    stop_tree=b_tree_create();
    query_tree=b_tree_create();

    ifstream fin,fin1;
    fin.open("stopwords.txt");
    while(!fin.eof())
    {        fin>>fileword;
            b_tree_insert(stop_tree,fileword);

    }
    fin.close();
    //inorder(stop_tree)

        system("cls");
        cout<<"\n                 ------------ MINI SEARCH ENGINE ------------ \n\n\n\n";



    cout<<"Enter the query : ";
    cin.getline(query,100);
    for(i=0;query[i]!='\0';i++)
    {
        if(query[i] ==' ')
        {
            word[++j]='\0';
           // cout << word << endl;

            strcpy(word,stemming(word));
            n=wordlookup(stop_tree,word);
            if(n==-1)
                b_tree_insert(query_tree,word);

            j=-1;

        }
        else
         {
            word[++j]=query[i];

         }
    }
    word[++j]='\0';
    //cout<<word;
    strcpy(word,stemming(word));
    n=wordlookup(stop_tree,word);
    if(n==-1)
       b_tree_insert(query_tree,word);



    i=0;
    fin.open("files1.txt");
    while(!fin.eof())
    {       fin>>file;
            //cout<<file<<endl<<endl;
                fin1.open(file);
                root=NULL;
                root=b_tree_create();
                while(!fin1.eof())
                {
                    fin1>>fileword;
                    strcpy(fileword,stemming(fileword));
                    if(strlen(fileword) >0)
                    {
                         n=wordlookup(stop_tree,fileword);
                        //cout<<fileword<<" "<<n<<endl;
                        if(n==-1)
                            b_tree_insert(root,fileword);
                    }


                }
                fin1.close();

                strcpy(result[i],file);
                n=calresult(query_tree,root);
                //cout<<n<<endl;
                tot[i]=n;
                ++i;
}

    fin.close();
 // n=calresult(query_tree,root);
//cout<<n;


  // traverse(root);
    //traverse(query_tree);
    for(x=0;x<=i-2;x++)
    {

        for(j=0;j<=i-2;j++)
        {
            if(tot[j]>tot[j+1])
            {
                t=tot[j];
                strcpy(word,result[j]);
                tot[j]=tot[j+1];
                strcpy(result[j],result[j+1]);
                tot[j+1]=t;
                strcpy(result[j+1],word);
            }
        }

    }

    cout<<"\n\n\n\nSEARCH RESULT : "<<endl<<endl;
    y=1;
     for(x=i-1;x>=0;x--)
    {
        if(tot[x]>0)
        {

            cout<<"            "<<y<<"."<<result[x]<<endl;
            ++y;
            flag=1;
        }

        if(y==4)
          break;
    }
    if(!flag)
        cout<<"NO RELATED SEARCHES";


}



