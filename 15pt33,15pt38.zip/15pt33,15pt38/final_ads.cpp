#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <vector>
#include <bitset>
#include <windows.h>

using namespace std;

const int rowsize=10;
const int colsize=10;
class maze;
class Graph;
struct LLnode;
LLnode* LL_insert(LLnode *head,int value);
void LL_display(LLnode *head);

COORD coord={0,0};
void gotoxy(int x,int y)
{
    coord.X=x;
    coord.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
class maze
{
    public:
    int row;
    int col;
    bool visit;
    int walls;
    enum wall{north=0x0008,east=0x0004,south=0x0002,west=0x0001,all=0x000f,none=0x0000};
    void init(int r,int c,int walls,bool v = false)
    {
        setposition(r,c);
        setwalls(walls);
        setvisited(v);
    }
    void setposition(int r,int c)
    {
        row=r;
        col=c;
    }
    maze()
    {
        init(0, 0, 0);
    }
    maze(int r,int c)
    {
         init(r,c,0);
    }

    maze(int r,int c,int w)
    {
        init(r,c,walls);
    }
    bool visited()
    {
        return visit;
    }
    void setvisited(bool v=true)
    {
        visit = v;
    }
    int getrow()
    {
        return row;
    }
    int getcolumn()
    {
        return col;
    }
    void removewall(int w)
    {
        walls=walls&~w;
    }
    int getwalls()const
    {
        return walls&all;
    }
    void setwalls(int w)
    {
        walls = w&all;
    }

    friend ostream& operator<<(ostream& out,const maze &cell)
    {
            if ((cell.getwalls()& maze::west)!= 0)
            out<<'|';
            else out<<' ';
            if ((cell.getwalls()& maze::south)!= 0)
            out<<'_';
            else out<<' ';

        return out;
    }
};

struct LLnode
{
    int value;
    LLnode *next;
};

class queue
{
     public :
        int v[rowsize*colsize];
        static int front,rear;
        void insert(int info)
        {
             rear++;
             v[rear]=info;

        }
        void deletenode()
        {
             int t;
             t=check_empty();
             if(t!=1)
             {
                 front++;
                 cout<<"\n\t"<<v[front]-1;
             }
             else
             {
                 cout<<"\n\tQueue is empty ";
             }
        }
        int check_empty()
        {
            if(front==rear)
            {
                 return 1;
            }
            else
            {
                 return 0;
            }
        }
};




class Graph
{
    int V;
    LLnode ** adjacency;
    int adjm[rowsize*colsize][rowsize*colsize];
public:
    Graph()
    {

        V=rowsize*colsize;
        int n=V;
        adjacency=new LLnode*[n];
        for(int i=0;i<n;++i)
        {
            adjacency[i]=NULL;
        }
       for(int i=0;i<rowsize*colsize;i++)
       {
           for(int j=0;j<rowsize*colsize;j++)
           {
               adjm[i][j]=0;
           }
       }
    }
    void Insert(maze cell[][colsize])
    {
    int count=0,v,adj;
    char n,e,s,w;
    int i,j;

    for(i=0;i<rowsize;i++)
    {
        for(j=0;j<colsize;j++)
        {

             string binary;
             binary=std::bitset<4>(cell[i][j].walls).to_string();
             n=binary[0];
             e=binary[1];
             s=binary[2];
             w=binary[3];

             v=count;

             if(n=='0')
             {
                if(i!=0)
                {
                    adj=v-colsize;
                    adjacency[v]=LL_insert(adjacency[v],adj);
                    adjm[v][adj]=1;
                }

             }
             if(e=='0')
             {

                if(j!=colsize-1)
                {
                    adj=v+1;
                    adjacency[v]=LL_insert(adjacency[v],adj);
                    adjm[v][adj]=1;
                }

             }
             if(s=='0')
             {
                 if(i!=rowsize-1)
                 {
                     adj=v+colsize;
                     adjacency[v]=LL_insert(adjacency[v],adj);
                     adjm[v][adj]=1;
                 }

             }
             if(w=='0')
             {
                 if(j!=0)
                 {
                     adj=v-1;
                     adjacency[v]=LL_insert(adjacency[v],adj);
                     adjm[v][adj]=1;
                 }


             }

            count++;
        }
    }
    /*for(i=0;i<rowsize*colsize;i++)
    {
        for(j=0;j<colsize*rowsize;j++)
        {
            cout<<adjm[i][j]<<" ";
        }
        cout<<endl;
    }
    */
    }

    void Display()
    {
        for(int i=0;i<V;++i)
        {
            if(adjacency[i]!=NULL)
            {
                cout<<"\nVertex:"<<i<<" is adjacent to:";
                LL_display(adjacency[i]);
            }
        }
    }


    bool isused(int v,int color[], int c)
    {
    for (int i = 0; i < V; i++)
        if (adjm[v][i] && c == color[i])
            return false;
    return true;
    }

    bool assigncolours(int m, int color[], int v)
    {
    if (v == V)
        return true;

    for (int c = 1; c <= m; c++)
    {
        if (isused(v,color,c))
        {
           color[v] = c;
           if (assigncolours(m, color, v+1) == true)
             return true;
           color[v] = 0;
        }
    }

    return false;
    }

    bool colorgraphs(int m)
   {

    int *color = new int[V];
    for (int i=0; i<V; i++)
       color[i] = 0;
    if (assigncolours(m,color,0) == false)
    {
      cout<<"Solution does not exist";
      return false;
    }

    print(color);
    return true;
   }

   void print(int color[])
   {
    int f=0;
    for (int i = 0; i < V; i++)
    {
        if(color[i]<=2)
        {
            f=1;
        }
        else
        {
            f=0;
            break;
        }
    }
    if(f==0)
    {
        cout<<"THERE DOES NOT EXIST A PATH\n";
    }
    else
    {
        cout<<"THERE EXIST A SINGLE PATH\n";
    }
    cout<<"\n";
   }

   void bfs()
   {
    int vis[rowsize*colsize];
    int root,i;
    for(int k=0;k<V;k++)
    {
        vis[k]=0;
    }
    cout<<"\nEnter the root vertex : ";
    cin>>root;
    LLnode *ptr;
    queue q;
    q.insert(root);
    vis[root-1]=1;

    int z;
    z=q.check_empty();
    while(z!=1)
    {
       root=root-1;
       ptr=adjacency[root];

       while(ptr!=NULL)
       {
            if(ptr->value!=root)
            {
                    i=ptr->value;
                    if(vis[i]==0)
                    {
                        q.insert(i+1);
                        vis[i]=1;
                    }

            }
            ptr=ptr->next;

        }
        q.deletenode();
        int y;
        if(!q.check_empty())
        {
            y=q.front;
            y++;
            root=q.v[y];
        }
        z=q.check_empty();
    }
   }

   void dfsprint(int v,int *vis)
   {
       vis[v]=1;
       cout<<v<<endl;
       int root=v;
       LLnode *ptr;
       ptr=adjacency[v];

       while(ptr!=NULL)
       {
            if(ptr->value!=root)        //checking for self loop
            {
                    v=ptr->value;
                    if(vis[v]==0)
                    {
                        dfsprint(v,vis);
                    }

            }
            ptr=ptr->next;

        }
   }

   void dfs()
   {
    int vis[rowsize*colsize];
    int root,i;
    for(int k=0;k<V;k++)
    {
        vis[k]=0;
    }
    cout<<"enter the root vertex";
    cin>>root;
    dfsprint(root-1,vis);
   }

};


LLnode* LL_insert(LLnode *head,int value)
{
    LLnode *temp=new LLnode;
    temp->value=value;
    temp->next=NULL;
    if(head==NULL)
    {
        head=temp;
        return head;
    }
    else
    {
        temp->next=head;
        head=temp;
        return head;
    }
}


void LL_display(LLnode* head)
{
    LLnode* ptr=head;
    while(ptr!=NULL)
    {
        cout<<ptr->value<<",";
        ptr=ptr->next;
    }
}


enum direction{north,south,east,west};
int queue::front=-1;
int queue::rear=-1;

int main(void)
{
   int ran_dir;
   srand(time(NULL));
   maze cell[rowsize][colsize];

   for(int row=0;row<rowsize;row++)
   {
      for(int col=0;col<colsize;col++)
      {
         cell[row][col].setvisited(false);
         cell[row][col].setposition(row, col);
         cell[row][col].setwalls(maze::all);
      }
   }
   int x=0;
   int y=0;
   vector<maze> trail;
   vector<direction> live;
   trail.push_back(cell[x][y]);
   while(trail.empty()==false)
    {
      live.clear();
      if(y)
         if(cell[x][y-1].getwalls()==maze::all)
            live.push_back(west);
      if(y<colsize-1)
      if(cell[x][y+1].getwalls()==maze::all)
         live.push_back(east);
      if(x)
      if(cell[x-1][y].getwalls()==maze::all)
         live.push_back(north);
      if(x<rowsize-1)
      if(cell[x+1][y].getwalls()==maze::all)
         live.push_back(south);
      if(live.empty()==false) {
         cell[x][y].setvisited(true);
         switch(live[rand() % live.size()]) {
           case 0:
               cell[x][y].removewall(maze::north);
               cell[--x][y].removewall(maze::south);
               break;
            case 1:
               cell[x][y].removewall(maze::south);
               cell[++x][y].removewall(maze::north);
               break;
            case 2:
               cell[x][y].removewall(maze::east);
               cell[x][++y].removewall(maze::west);
               break;
            case 3:
               cell[x][y].removewall(maze::west);
               cell[x][--y].removewall(maze::east);
               break;

         }
         trail.push_back(cell[x][y]);
      }
      else {

         trail.pop_back();

         if(trail.empty()==false) {
            x=trail[0].getrow();
            y=trail[0].getcolumn();
         }
      }
   }
    system("color B");
    cout<<"������������������������������������Ŀ";
    cout<<"\n";
    cout<<"� ������ THE GENERATED MAZE IS �������";
    cout<<"\n";
    cout<<"��������������������������������������";
    cout<<"\n\n\n";


    int r, c,n;
    for (c=0; c<colsize; c++)
    {
        if (c == 0) cout << " _";
        else cout << "__";
    }
    cout << '\n';
    for (r=0; r<rowsize; r++)
    {
        for (c=0; c<colsize; c++) {
            cout << cell[r][c];
        }
        cout << "|\n";
    }

    Graph g;
    g.Insert(cell);
    cout<<"\n";
    cout<<"\n";
    cout<<"\n";
   do
   {
    cout<<"\n";
    cout<<"������������������������������������Ŀ";
    cout<<"\n";
    cout<<"�       ENTER YOUR CHOICE            �";
    cout<<"\n";
    cout<<"��������������������������������������";
    cout<<"\n";


    cout<<"�������������������������������������Ŀ";
    cout<<"\n";
    cout<<"�1.DISPLAY ADJACENCY                  �"<<"\n";
    cout<<"�2.BREADTH FIRST TRAVERSAL            �"<<"\n";
    cout<<"�3.DEPTH FIRST TRAVERSAL              �"<<"\n";
    cout<<"�4.EXIT                               �"<<"\n";
    cout<<"�                                     �"<<"\n";
    cout<<"�                                     �"<<"\n";
    cout<<"���������������������������������������"<<"\n";


                fflush(stdin);
                cin>>n;

    switch(n)
    {
        case 1:g.Display();
               g.colorgraphs(2);
               break;
        case 2:g.bfs();
                break;
        case 3:g.dfs();
                break;
        case 4:exit(0);
                break;
    }

   }while(n!=4);
}









