#include<iostream>
#include<conio.h>
#include<string.h>
#include <windows.h>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <ctime>
#include <dos.h>
#include <iomanip>


using namespace std;


void schoice();
int i,j,li,lp,rec,valid;
char choice;
int ch;
string a1,a2;
int dd,mm,yy;
string text;

class link
{
	link *next;
	char user[100],pwd[100];
	public:
	link()
	{
		next=NULL;
	}
	link *crnode(char *name,char *pass)
	{
		link *temp1=new link;
		strcpy(temp1->user,name);
		strcpy(temp1->pwd,pass);
		temp1->next=NULL;
		return temp1;
	}
	link ins(link *temp)
	{
		temp->next=this;
	}
	void search(char *name)
	{
		link *temp=this;
		int flag=0;
		while(temp!=NULL)
		{
			if(strcmp(temp->user,name)==0)
			{
				flag=1;
				cout<<"found "<<pwd;
				break;
			}
			else
			{
				temp=temp->next;
			}

		}
		if(flag==0)
			cout<<"not found";
	}
	void traverse(link *x)
	{
		link *temp=x;
		while(temp!=NULL)
		{
			cout<<temp->user<<" ";
			temp=temp->next;
		}
		cout<<"\n";

	}
};
class hash
{
	link **array;
	int length;
	public:
	hash(int len)
	{
		length=len;
		array=new link*[len];
		int i;
		for(i=0;i<len;++i)
		{
			array[i]=NULL;
		}
	}
	int hashfn(char *name)
	{
		int l;
		l=strlen(name);
		int i,sum=0;
		for(i=0;i<l;++i)
		{
			sum+=name[i];
		}
		return sum;
	}
	void insert(char *name,char *pass)
	{
		int val=0;
		val=hashfn(name);
		//cout<<val;
		val%=length;
		//cout<<val;
		link x;
		link *temp=x.crnode(name,pass);
		//array[8]->traverse(array[8]);
		if(array[val]==NULL)
			array[val]=temp;
		else
		{
			array[val]->ins(temp);
			array[val]=temp;
		}

	}
	void search(char *name)
	{
		int val;

		val=hashfn(name);
		cout<<val;
		val%=length;
		if(array[val]!=NULL)
		{
			cout<<val;
			array[val]->search(name);
		}
	}
	void disp()
	{
		cout<<"\n\n\n";
		int i;
		for(i=0;i<length;++i)
		{

			if(array[i]!=NULL)
				array[i]->traverse(array[i]);
		}
	}
};


int date_val(int mm)
{
        if(mm<1||mm>12)
                return 0;
        else
                return 1;
}

int date_val(int dd,int mm)
{
        switch(mm)
        {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:if(dd<1||dd>31)
                                return 0;
                        else
                                return 1;
                case 2:if(dd<1||dd>29)
                                return 0;
                        else
                                return 1;
                default:if(dd<1||dd>30)
                                return 0;
                        else
                                return 1;
        }
}

void signup()
{
    system("cls");
    int ch,i;
    int ques1,ques2;
    int value,flag=0,cnt=0;

    char name[20],uname[20];
    char pw1[30],pw2[30],d;
    cout<<"Enter your name:";
    cin>>name;
    do
    {
        cout<<"Enter your user name:";
        cin>>uname;
        string line;
        fstream file2("unpw.txt",ios::in);
        cnt=0;
        while(!file2.eof())
        {
            cnt++;
            if(cnt%2==0)
            {
                getline(file2,line);
                continue;
            }
            getline(file2,line);
            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,uname))
            {
                cout<<"username already present...try some other name...";
                flag=1;
                break;
            }
            else
                flag=0;
        }
        file2.close();
    }while(flag==1);
    do
    {
        cout<<"enter your password(# to terminate)...";
        i=0;
        do
        {
            d=getch();
            cout<<"*";
            pw1[i++]=d;
        }while(d!='#');
        //cout<<"done...";
        pw1[i-1]=NULL;
        //getch();
        //cout<<pw1;
        cout<<endl<<"\nre-enter...";
        i=0;
        do
        {
            d=getch();
            cout<<"*";
            pw2[i++]=d;
        }while(d!='#');
        pw2[i-1]=NULL;
        if(strcmp(pw1,pw2))
            cout<<"passwords arent matching...pls try again...";
        else
            break;
    }while(1);
    cout<<endl<<"Enter your date of birth:<dd(space)mm(space)yy>";
    cin>>dd>>mm>>yy;
    value=date_val(dd,mm);
    while(value==0)
    {
        cout<<"invalid date entered...enter again..."<<endl;
        cin>>dd;
        value=date_val(dd,mm);
    }
    value=date_val(mm);
    while(value==0)
    {
        cout<<"month should be between 1 and 12...enter again..."<<endl;
        cin>>mm;
        value=date_val(mm);
    }
    cout<<" SECURITY QUESTIONS  "<<endl;
    cout<<"choose the question from the following set::"<<endl;
        ifstream file;
        file.open("ques.txt");
        cout<<"     QUESTIONS:"<<endl;

        if(file.is_open())
        {
            string line;
            i=1;
            while(i<=15)
            {
                getline(file,line);
                cout<<line<<endl;
                i++;
            }
        }
        file.close();
        cout<<"Enter question number 1:";
        cin>>ques1;
        if(ques1<1||ques1>15)
        {
            cout<<"Choose a question within 1-15"<<endl;
            cout<<"Enter again:";
            cin>>ques1;
        }
        cout<<"Enter answer for the question:";
        cin>>a1;
        cout<<"Enter question number 2";
        cin>>ques2;
        if(ques2<1||ques2>15)
        {
            cout<<"Choose a question within 1-15"<<endl;
            cout<<"Enter again:";
            cin>>ques2;
        }
        cout<<"Enter answer for the question:";
        cin>>a2;
        //cout<<"check1";
        char userr[20];
        strcpy(userr,uname);
        strcat(userr,".txt");
        fstream file3("unpw.txt",ios::in|ios::out|ios::app);
        fstream file4(userr,ios::in|ios::out|ios::app);
        file3<<endl<<uname<<endl<<pw1;
        file4<<name<<endl<<uname<<endl<<pw1<<endl<<dd<<endl<<mm<<endl<<yy<<endl<<ques1<<endl<<a1<<endl<<ques2<<endl<<a2<<endl;
}

void modify(int change,char uname[20],char pw[30])
{
    char newuname[20],newpw[30],d;
    int cnt=0;
    fstream file("temp.txt",ios::in|ios::out|ios::trunc);
    if(change==1)
    {
        string line;
        fstream file2("unpw.txt",ios::in);
        cnt=0;
        while(!file2.eof())
        {
            cnt++;
            if(cnt%2==0)
            {
                getline(file2,line);
                file<<line<<endl;
                continue;
            }
            getline(file2,line);

            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,uname))
                break;
            else
              file<<line<<endl;
        }
        cout<<"enter the new username...";
        cin>>newuname;
        file<<newuname<<endl;
        while(!file2.eof())
        {
            getline(file2,line);
            file<<line<<endl;
        }
        //cout<<"check";
        file.close();
        file2.close();
        char newname[30];
        strcpy(newname,newuname);
        strcat(newname,".txt");
        strcat(uname,".txt");
        fstream filen(uname,ios::in);
        fstream filenn("temp1.txt",ios::in|ios::out|ios::trunc);
        getline(filen,line);
        filenn<<line<<endl;
        getline(filen,line);
        filenn<<newuname<<endl;
        while(!filen.eof())
        {
            getline(filen,line);
            filenn<<line<<endl;
        }
        filen.close();
        filenn.close();
        rename("unpw.txt","unpw1.txt");
        remove("unpw1.txt");
        rename("temp.txt","unpw.txt");
        remove(uname);
        rename("temp1.txt",newname);
    }
    else if(change==2)
    {
        string line;
        fstream file2("unpw.txt",ios::in);
        cnt=0;
        while(!file2.eof())
        {
            cnt++;
            if(cnt%2!=0)
            {
                getline(file2,line);
                file<<line<<endl;
                continue;
            }
            getline(file2,line);

            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,pw))
                break;
            else
              file<<line<<endl;
        }
        cout<<"enter ur new password(# to terminate)...";
        i=0;
        do
        {
            d=getch();
            cout<<"*";
            newpw[i++]=d;
        }while(d!='#');
        newpw[i-1]=NULL;
        file<<newpw<<endl;
        while(!file2.eof())
        {
            getline(file2,line);
            file<<line<<endl;
        }
        //cout<<"check";
        file.close();
        file2.close();


        strcat(uname,".txt");
        fstream file3(uname,ios::in);
        fstream file4("temp1.txt",ios::in|ios::out|ios::trunc);
        getline(file3,line);
        file4<<line<<endl;
        getline(file3,line);
        file4<<line<<endl;
        file4<<newpw<<endl;
        getline(file3,line);
        while(!file3.eof())
        {
            getline(file3,line);
            file4<<line<<endl;
        }
        file3.close();
        file4.close();
        remove("unpw.txt");
        rename("temp.txt","unpw.txt");
        //cout<<uname<<"checkbfjegfiwuehf";
        remove(uname);
        rename("temp1.txt",uname);
    }
    else
    {
        string line;
        fstream file2("unpw.txt",ios::in);
        cnt=0;
        while(!file2.eof())
        {
            cnt++;
            if(cnt%2==0)
            {
                getline(file2,line);
                file<<line<<endl;
                continue;
            }
            getline(file2,line);

            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,uname))
                break;
            else
              file<<line<<endl;
        }
        cout<<"enter the new username...";
        cin>>newuname;
        cout<<"enter new password(# to terminate)...";
        i=0;
        do
        {
            d=getch();
            cout<<"*";
            newpw[i++]=d;
        }while(d!='#');
        newpw[i-1]=NULL;

        file<<newuname<<endl<<newpw<<endl;
        getline(file2,line);
        while(!file2.eof())
        {
            getline(file2,line);
            file<<line<<endl;
        }
        //cout<<"check";
        file.close();
        file2.close();

        strcat(uname,".txt");
        char newname1[30];
        strcpy(newname1,newuname);
        strcat(newname1,".txt");
        fstream file3(uname,ios::in);
        fstream file4("temp1.txt",ios::in|ios::out|ios::trunc);
        getline(file3,line);
        file4<<line<<endl;
        getline(file3,line);
        file4<<newuname<<endl;
        file4<<newpw<<endl;
        getline(file3,line);
        while(!file3.eof())
        {
            getline(file3,line);
            file4<<line<<endl;
        }
        file3.close();
        file4.close();
        remove("unpw.txt");
        rename("temp.txt","unpw.txt");
        remove(uname);
        rename("temp1.txt",newname1);

        //remove("unpw.txt");
        //rename("temp.txt","unpw.txt");

    }
    cout<<"successfully updated...";
}

void removeacc(char uname[20],char pw[30])
{
    char userr[30];
    strcpy(userr,uname);
    strcat(userr,".txt");
    string line;
    int cnt=0;
    fstream file("temp.txt",ios::in|ios::out|ios::trunc);
    fstream file2("unpw.txt",ios::in);
    while(!file2.eof())
    {
        cnt++;
            if(cnt%2==0)
            {
                getline(file2,line);
                file<<line<<endl;
                continue;
            }
            getline(file2,line);

            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,uname))
            {
                getline(file2,line);
                break;
            }
            else
              file<<line<<endl;
    }
    while(!file2.eof())
    {
        getline(file2,line);
        file<<line<<endl;
    }
    file2.close();
    file.close();
    remove("unpw.txt");
    rename("temp.txt","unpw.txt");
    remove(userr);
    cout<<"successfully removed...";
}


void signin()
{
    char uname[20],pw[30],d;
    system("cls");
    int ch1,cnt=0,flag=0;
    string line;

    //cout<<"check..";
    do
    {
        cout<<"Enter your user name:";
        cin>>uname;
        string line;
        fstream file2("unpw.txt",ios::in);
        cnt=0;
        while(!file2.eof())
        {
            cnt++;
            if(cnt%2==0)
            {
                getline(file2,line);
                continue;
            }
            getline(file2,line);
            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,uname))
            {
                getline(file2,line);
                flag=1;
                break;
            }
            else
                flag=0;
        }
        if(flag==0)
            cout<<"the name u entered..is not in the username list,....enter again...";
        file2.close();
    }while(flag==0);

    cout<<"enter password(# to terminate)...";
    i=0;
        do
        {
            d=getch();
            cout<<"*";
            pw[i++]=d;
        }while(d!='#');
        pw[i-1]=NULL;
    fstream fptr("unpw.txt",ios::in);
    do
    {
    cnt=0;
        while(!fptr.eof())
        {
            cnt++;
            if(cnt%2==0)
            {
                getline(fptr,line);
                continue;
            }
            getline(fptr,line);
            char * ll = new char[line.length() + 1];
            strcpy(ll,line.c_str());
            if(!strcmp(ll,uname))
            {
                getline(fptr,line);
                strcpy(ll,line.c_str());
                while(1)
                {
                    if(!strcmp(pw,ll))
                    {
                        cout<<"authentication successful...."<<endl;
                        break;
                    }
                    else
                    {
                        cout<<"wrong password...enter again...";
                        i=0;
                        do
                        {
                            d=getch();
                            cout<<"*";
                            pw[i++]=d;
                        }while(d!='#');
                        pw[i-1]=NULL;
                    }
                }
                flag=1;
                break;
            }
            else
                flag=0;
        }
        //cout<<"check23232";
        fptr.close();
    }while(flag!=1);
    if(1)
    {
        cout<<endl<<"WELCOME"<<endl;
        cout<<"Do you want to:"<<endl;
        cout<<"1. Modify Account"<<endl;
        cout<<"2. Delete Account"<<endl;
        cout<<"3. Exit"<<endl;
        cout<<"Enter your choice:";
        cin>>ch1;
        int change;
        if(ch1==1)
        {
            cout<<"What do you want to change?"<<endl;
            cout<<"1.Username"<<endl;
            cout<<"2.Password"<<endl;
            cout<<"3.Both"<<endl;
            cin>>change;
            modify(change,uname,pw);
        }
        else if(ch1==2)
            removeacc(uname,pw);
        else if(ch1==3)
        {
            //system("cls");
            //schoice();
            return;
        }
        else
            cout<<"You entered wrong choice...Enter again"<<endl;
    }
}


void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void schoice()
{
    system("cls");
    for(li=30;li<=50;li++)
    {
        gotoxy(li,14);
        Sleep(30);
        printf("*");

    }

    for(li=50;li>=30;li--)
    {
        gotoxy(li,30);
        Sleep(30);
        printf("*");
    }

    for(lp=15;lp<30;lp++)
    {
        gotoxy(30,lp);
        Sleep(100);
        printf("|");
    }

    for(lp=29;lp>=15;lp--)
    {
        gotoxy(50,lp);
        Sleep(100);
        printf("|");
    }

    gotoxy(15,10);
    printf("what do you want to do?\n");
    gotoxy(35,16);

    printf("1.SIGN-UP");
    gotoxy(35,20);
    printf("2.SIGN-IN");
    gotoxy(35,24);
    printf("3.QUIT");
    while(1)
    {
    choice=getch();
    switch(choice)
    {
        case '1':signup();
                break;
        case '2':signin();
            cout<<"returned..";
                break;
        case '3':exit(0);
        default:gotoxy(33,40);
            cout<<"Illegal Choice"<<endl;
    }
    if(choice=='1'||choice=='2')
        break;
}
}



main()
{
	hash h(13);
	int chch;
	if(!std::ifstream("unpw.txt"))
    {
        fstream file("unpw.txt",ios::in|ios::out|ios::trunc);
        file.close();
    }

    while(1)
    {
        system("cls");
        cout<<"Press any key to continue..";
        getch();
        schoice();
        system("cls");
        cout<<"press 1 to continue...any other key to exit";
        cin>>chch;
        if(chch!=1)
            break;
    }
    fstream file("unpw.txt",ios::in);
    string line1,line2;
    char *l1,*l2;
    while(!file.eof())
    {
        getline(file,line1);
        getline(file,line2);
        char * l1 = new char[line1.length() + 1];
        strcpy(l1,line1.c_str());
        char * l2 = new char[line2.length() + 1];
        strcpy(l2,line2.c_str());
        h.insert(l1,l2);
    }
    system("cls");
    cout<<"displaying from the hash table(user names)..."<<endl;
    h.disp();
    getch();
    system("cls");
    cout<<"\t\t\t\tADS PACKAGE"<<endl;
    cout<<"\t\t\t\tS.SUPRAJA(15PT35)"<<endl;
    cout<<"\t\t\t\tE.VEENA(15PT39)"<<endl<<endl;
    cout<<"\t\t\t\tTHANK YOU..."<<endl;
	//h.insert("hello","bello");
	//h.insert("gellp","han");
	//cout<<"hai";


	//h.insert("axe","bad");
	//h.insert("bxd","led");

}
