//#pragma once
#include<time.h>
#include <string>
#include <sstream>
//#include <iostream>
#include <cstring>
#include <iostream>
#include<fstream>
//#include"mytest1.txt"
using namespace std;
struct SinglyLinkedListItem
{
  void *info;
  SinglyLinkedListItem *next;
};

class SinglyLinkedList
{
protected:
  SinglyLinkedListItem *head;
  int size;

  SinglyLinkedListItem *SearchGeneric(void *info);
  void AddGeneric(void *info);
  void DeleteGeneric(void *info);

public:
  SinglyLinkedList(void);
  virtual ~SinglyLinkedList(void);

  SinglyLinkedListItem *GetHead(void);
  int GetSize(void);

  virtual void Print(void);
};

struct Gene;

class GeneNameList : public SinglyLinkedList
{
public:
  GeneNameList(void);
  ~GeneNameList(void);

  void Add(const char *name);
  void Delete(const char *name);
  void DeleteAll(void);

  void Print(void);
  void PrintErr(void);

  const char *GetFirstName(void);
};
class GeneList : public SinglyLinkedList
{
public:
  GeneList(void);
  ~GeneList(void);

  void Add(Gene *gene);
  void Delete(Gene *gene);

  void Print(void);
  void PrintErr(void);

  void RemoveFromNeighborLists(Gene *gene);
};
struct Gene
{
  int x1, x2;
  GeneNameList names;
  GeneList predecessors, successors;

  const char *GetFirstName(void);
};

struct GeneDictionaryNode
{
  char *name;
  Gene *gene;
  GeneDictionaryNode *left, *right, *up;

  GeneDictionaryNode(char *name, Gene *gene, GeneDictionaryNode *left, GeneDictionaryNode *right, GeneDictionaryNode *up);
};

class GeneDictionary
{
  GeneDictionaryNode *root;
  GeneList *geneList;

  void Splaying(GeneDictionaryNode *&root, const char *name);

  void DeleteSplayingSubtree(GeneDictionaryNode *root);

public:
  GeneDictionary(void);
  virtual ~GeneDictionary(void);

  bool AddGene(const char *name, int x1, int x2);
  bool AddGeneAlias(const char *name1, const char *name2);
  bool RemoveAlias(const char *name);
  bool PrintGeneInfo(const char *name);

  Gene *GetGene(const char *name);
  GeneList *GetGeneList(void);

  bool GeneDeleted(void);

  void PrintGeneMapping(void);
};

class GeneGraphPath : public SinglyLinkedList
{
  SinglyLinkedListItem *tail;

public:
  GeneGraphPath(void);
  ~GeneGraphPath(void);

  GeneGraphPath *Clone(void);
  void AddGene(Gene *gene);

  Gene *GetLastGene(void);
  bool Contains(Gene *gene);

  void Print(void);
};


class GeneGraph
{
  GeneDictionary *geneDictionary;

public:
  GeneGraph(GeneDictionary *geneDictionary);
  virtual ~GeneGraph(void);

  bool AddEdge(const char *name1, const char *name2);
  bool DeleteEdge(const char *name1, const char *name2);

  void Print(void);
  void PrintFeedBackLoops(int k, const char *name);
};

SinglyLinkedList::SinglyLinkedList(void)
{
  head = NULL;
  size = 0;
}

SinglyLinkedList::~SinglyLinkedList(void)
{
}

SinglyLinkedListItem *SinglyLinkedList::SearchGeneric(void *info)
{
  SinglyLinkedListItem *p;

  for (p=head; p != NULL; p=p->next)
      if (p->info == info)
	return p;

  return NULL;
}

void SinglyLinkedList::AddGeneric(void *info)
{
  SinglyLinkedListItem *item = new SinglyLinkedListItem();
  item->info = info;
  item->next = head;

  head = item;

  size++;
}

void SinglyLinkedList::DeleteGeneric(void *info)
{
  SinglyLinkedListItem *p, *q;

  for (p=head, q=NULL; p != NULL; q=p, p=p->next)
    if (p->info == info)
	{
	  if (q != NULL)
	    q->next = p->next;
	  else
	    head = p->next;
	  delete p;


	  break;
	}

  size--;
}

int SinglyLinkedList::GetSize(void)
{
  return size;
}

SinglyLinkedListItem *SinglyLinkedList::GetHead(void)
{
  return head;
}

void SinglyLinkedList::Print(void)
{
}

GeneNameList::GeneNameList(void) : SinglyLinkedList()
{
}

GeneNameList::~GeneNameList(void)
{
  DeleteAll();
}

void GeneNameList::Add(const char *name)
{
  AddGeneric((void*)name);
}

void GeneNameList::Delete(const char *name)
{
  SinglyLinkedListItem *p, *q;

  for (p=head, q=NULL; p != NULL; q=p, p=p->next)
    if (strcmp((char*)p->info, name) == 0)
      {
	if (q != NULL)
	  q->next = p->next;
	else
	  head = p->next;
	delete (const char*)(p->info);

	break;
      }

  size--;
}

void GeneNameList::DeleteAll(void)
{
  SinglyLinkedListItem *p, *q;

  for (p=head; p != NULL; p=q)
    {
      q = p->next;

      delete (const char*)(p->info);
      delete p;
    }

  size = 0;
}

void GeneNameList::Print(void)
{
  SinglyLinkedListItem *p;

  for (p=head; p != NULL; p=p->next)
    {
      cout << (const char*)(p->info);

      if (p->next != NULL)
	cout << " ";
    }
}

void GeneNameList::PrintErr(void)
{
  SinglyLinkedListItem *p;

  for (p=head; p != NULL; p=p->next)
    {
      cerr << (const char*)(p->info);

      if (p->next != NULL)
	cerr << " ";
    }
  cerr << "\n";
}

const char *GeneNameList::GetFirstName(void)
{
  if (head == NULL)
    return NULL;

  return (const char*)head->info;
}
GeneList::GeneList(void) : SinglyLinkedList()
{
}

GeneList::~GeneList(void)
{
  SinglyLinkedListItem *p, *q, *r, *s;

  for (p=head; p != NULL; p=q)
    {
      q = p->next;

      Gene *g = (Gene*)(p->info);
      g->names.DeleteAll();

      for (r=g->successors.head; r != NULL; r=s)
	{
	  s = r->next;
	  delete r;
	}
      for (r=g->predecessors.head; r != NULL; r=s)
	{
	  s = r->next;
	  delete r;
	}

      delete p;
    }
}

void GeneList::Add(Gene *gene)
{
  if (SearchGeneric((void*)gene) == NULL)
    AddGeneric((void*)gene);
}

void GeneList::Delete(Gene *gene)
{
  DeleteGeneric((void*)gene);
}

void GeneList::Print(void)
{
  SinglyLinkedListItem *p, *q;

  for (p=head; p != NULL; p=p->next)
    {
      Gene *g1 = (Gene*)p->info;
      const char *name1 = g1->GetFirstName();

      for (q=g1->successors.head; q != NULL; q=q->next)
	{
	  Gene *g2 = (Gene*)q->info;
	  const char *name2 = g2->GetFirstName();

	  cout << name1 << " -> " << name2 << "\n";
	}
    }
}

void GeneList::PrintErr(void)
{
  SinglyLinkedListItem *p, *q;

  cerr << size << "\n";

  for (p=head; p != NULL; p=p->next)
    {
      Gene *g = (Gene*)p->info;
      g->names.PrintErr();
    }
}

void GeneList::RemoveFromNeighborLists(Gene *gene)
{
  SinglyLinkedListItem *p, *q, *r;

  for (p=gene->predecessors.head; p != NULL; p=p->next)
    {
      Gene *gSearched = (Gene*)(p->info);

      for (q=NULL, r=gSearched->successors.head; r != NULL; q=r, r=q->next)
	if ((Gene*)(r->info) == gene)
	  {
	    if (q == NULL)
	      gSearched->successors.head = r->next;
	    else
	      q->next = r->next;
	    delete r;

	    break;
	  }
    }
}

const char *Gene::GetFirstName(void)
{
  return names.GetFirstName();
}

GeneDictionaryNode::GeneDictionaryNode(char *name, Gene *gene, GeneDictionaryNode *left, GeneDictionaryNode *right, GeneDictionaryNode *up)
{
  this->name = name;
  this->gene = gene;
  this->left = left;
  this->right = right;
  this->up = up;
}


GeneDictionary::GeneDictionary(void)
{
  root = NULL;
  geneList = new GeneList();
}

GeneDictionary::~GeneDictionary(void)
{
  DeleteSplayingSubtree(root);

  delete geneList;
}

void GeneDictionary::DeleteSplayingSubtree(GeneDictionaryNode *root)
{
  if (root == NULL)
    return;

  DeleteSplayingSubtree(root->left);
  DeleteSplayingSubtree(root->right);

  delete root;
}

void GeneDictionary::Splaying(GeneDictionaryNode *&root, const char *name)
{
  GeneDictionaryNode *o, *p, *q;

  // find node containing "name"
  q = NULL;
  p=root;
  while ( p != NULL )
    {
      q = p;

      int rel = strcmp(name, p->name);
      if (rel < 0)
	p = p->left;
      else
      if (rel > 0)
	p = p->right;
      else
	break;
    }

  // move node up with a series of rotations
  while (q != root)
    {
      p = q->up;

      if (p == root)
      {
	  if (p->left == q)
	    {
	      p->left = q->right;
	      if (q->right != NULL)
            q->right->up = p;

	      q->right = p;
	      q->up = p->up;
	      p->up = q;
	    }
	  else
	    {
	      p->right = q->left;
	      if (q->left != NULL)
            q->left->up = p;

	      q->left = p;
	      q->up = p->up;
	      p->up = q;
	    }

	  if (q->up != NULL)
	    if (q->up->left == p)
	      q->up->left = q;
	    else
	      q->up->right = q;

	  root = q;
	}
      else
	{
	  o = p->up;

	  bool rootReached;
	  rootReached = root == o;

	  if ((o->left == p) && (p->left == q))
	    {
	      p->left = q->right;
	      if (q->right != NULL)
            q->right->up = p;

	      o->left = p->right;
	      if (p->right != NULL)
            p->right->up = o;

	      q->right = p;
	      q->up = o->up;
	      p->right = o;
	      p->up = q;
	      o->up = p;
	    }
	  else
	  if ((o->left == p) && (p->right == q))
	    {
	      p->right = q->left;
	      if (q->left != NULL)
            q->left->up = p;

	      o->left = q->right;
	      if (q->right != NULL)
            q->right->up = o;

	      q->left = p;
	      q->right = o;
	      p->up = q;
	      q->up = o->up;
	      o->up = q;
	    }
	  else
	  if ((o->right == p) && (p->left == q))
	    {
	      o->right = q->left;
	      if (q->left != NULL)
            q->left->up = o;

	      p->left = q->right;
	      if (q->right != NULL)
            q->right->up = p;

	      q->left = o;
	      q->right = p;
	      p->up = q;
	      q->up = o->up;
	      o->up = q;
	    }
	  else
	  if ((o->right == p) && (p->right == q))
	    {
	      o->right = p->left;
	      if (p->left != NULL)
            p->left->up = o;

	      p->right = q->left;
	      if (q->left != NULL)
            q->left->up = p;

	      q->left = p;
	      q->up = o->up;
	      p->left = o;
	      p->up = q;
	      o->up = p;
	    }

	  if (q->up != NULL)
	    if (q->up->left == o)
	      q->up->left = q;
	    else
	      q->up->right = q;

	  if (rootReached)
	    root = q;
        }
    }
}

bool GeneDictionary::AddGene(const char *name, int x1, int x2)
{
  char *nameCopy = strdup(name);

  Gene *gene = new Gene();
  gene->names.Add(nameCopy);
  gene->x1 = x1;
  gene->x2 = x2;

  if (root == NULL)
    {
      root = new GeneDictionaryNode(nameCopy, gene, NULL, NULL, NULL);
    }
  else
    {
      GeneDictionaryNode *node;

      Splaying(root, nameCopy);

      int rel = strcmp(root->name, nameCopy);
      if (rel < 0)
	{
	  node = new GeneDictionaryNode(nameCopy, gene, root, root->right, NULL);
	  if (node->right != NULL)
	    node->right->up = node;

	  root->right = NULL;
	  root->up = node;

	  root = node;
	}
      else
      if (rel > 0)
	{
	  node = new GeneDictionaryNode(nameCopy, gene, root->left, root, NULL);
	  if (node->left != NULL)
	    node->left->up = node;

	  root->left = NULL;
	  root->up = node;

	  root = node;
	}
      else
	{
	  delete gene;
	  return false;
	}
    }

  geneList->Add(gene);

  return true;
}

bool GeneDictionary::AddGeneAlias(const char *name1, const char *name2)
{
  Gene *gene;
  Splaying(root, name1);
  if ((root == NULL) || (strcmp(root->name, name1) != 0))
    return false;
  gene = root->gene;

  char *nameCopy = strdup(name2);
  Splaying(root, name2);

  GeneDictionaryNode *node;

  int rel = strcmp(root->name, nameCopy);
  if (rel < 0)
    {
      node = new GeneDictionaryNode(nameCopy, gene, root, root->right, NULL);
      if (node->right != NULL)
	node ->right->up = node;

      root->right = NULL;
      root->up = node;

      root = node;
    }
  else
  if (rel > 0)
    {
      node = new GeneDictionaryNode(nameCopy, gene, root->left, root, NULL);
      if (node->left != NULL)
	node->left->up = node;

      root->left = NULL;
      root->up = node;

      root = node;
    }
  else
    {
      delete nameCopy;
      return false;
    }

  gene->names.Add(nameCopy);

  return true;
}

bool GeneDictionary::RemoveAlias(const char *name)
{
  Splaying(root, name);
  if ((root == NULL) || (strcmp(root->name, name) != 0))
    return false;

  root->gene->names.Delete(name);
  if (root->gene->names.GetSize() == 0)
    {
      geneList->Delete(root->gene);
      geneList->RemoveFromNeighborLists(root->gene);
    }

  if (root->left == NULL)
    {
      root = root->right;
      if (root != NULL)
	root->up = NULL;
    }
  else
    {
      Splaying(root->left, name);

      root->left->right = root->right;
      root->left->up = NULL;

      if (root->right != NULL)
	root->right->up = root->left;

      root = root->left;
    }

  return true;
}

bool GeneDictionary::PrintGeneInfo(const char *name)
{
  Gene *g = GetGene(name);
  if (g == NULL)
    return false;

  cout << g->x1 << " " << g->x2 << " ";
  g->names.Print();
  cout << "\n";

  return true;
}

Gene *GeneDictionary::GetGene(const char *name)
{
  Splaying(root, name);
  if ((root == NULL) || (strcmp(root->name, name) != 0))
      return NULL;

  return root->gene;
}

GeneList *GeneDictionary::GetGeneList(void)
{
  return geneList;
}

void GeneDictionary::PrintGeneMapping(void)
{
  geneList->PrintErr();
}

GeneGraph::GeneGraph(GeneDictionary *geneDictionary)
{
  this->geneDictionary = geneDictionary;
}

GeneGraph::~GeneGraph(void)
{
}

bool GeneGraph::AddEdge(const char *name1, const char *name2)
{
  Gene *g1 = geneDictionary->GetGene(name1);
  Gene *g2 = geneDictionary->GetGene(name2);
  if ((g1 == NULL) || (g2 == NULL))
    return false;

  g1->successors.Add(g2);
  g2->predecessors.Add(g1);

  return true;
}

bool GeneGraph::DeleteEdge(const char *name1, const char *name2)
{
  Gene *g1 = geneDictionary->GetGene(name1);
  Gene *g2 = geneDictionary->GetGene(name2);
  if ((g1 == NULL) || (g2 == NULL))
    return false;

  g1->successors.Delete(g2);
  g2->predecessors.Delete(g1);

  return true;
}

void GeneGraph::Print(void)
{
  cout << "digraph {\n";
  geneDictionary->GetGeneList()->Print();
  cout << "}\n";
}

GeneGraphPath::GeneGraphPath(void) : SinglyLinkedList()
{
  tail = NULL;
}

GeneGraphPath::~GeneGraphPath(void)
{
  SinglyLinkedListItem *p, *q;

  for (p=head; p != NULL; p=q)
    {
      q = p->next;

      delete p;
    }

  size = 0;
}

/*GeneGraphPath *GeneGraphPath::Clone(void)
{
  GeneGraphPath *path = new GeneGraphPath();
  SinglyLinkedListItem *p;
  for (p=head; p != NULL; p=p->next)
    path->AddGene((Gene*)(p->info));

  return path;
}*/

void GeneGraphPath::AddGene(Gene *gene)
{
  SinglyLinkedListItem *item = new SinglyLinkedListItem();
  item->info = (void*)gene;
  item->next = NULL;

  if (head == NULL)
    {
      head = item;
      tail = item;
    }
  else
    {
      tail->next = item;
      tail = item;
    }

  size++;
}

Gene *GeneGraphPath::GetLastGene(void)
{
  return (Gene*)(tail->info);
}

bool GeneGraphPath::Contains(Gene *gene)
{
  SinglyLinkedListItem *p;

  for (p=head; p != NULL; p=p->next)
    if ((Gene*)(p->info) == gene)
      return true;

  return false;
}

void GeneGraphPath::Print(void)
{
  SinglyLinkedListItem *p;

  for (p=head; p != NULL; p=p->next)
    {
      Gene *g = (Gene*)(p->info);
      cout << g->names.GetFirstName();

      if (p->next != NULL)
	cout << " ";
    }
}
int ExtractFiles(GeneDictionary &d,GeneGraph &g)
{
    ifstream fin;
    fin.open("mytest2.txt",ios::in);
    string command;
    string name,x1, x2;
    string name1,name2;
    if(!fin)
    {
        cout<<"*********FILE NOT AVAILABLE***********\n";
        return 0;
    }
    while(1)
    {

        fin>>command;
        if(command== "Quit")
        {
            //fin<<"\r";
            cout<<"GRAPH CREATED !!!  (file exist)"<<endl;
            fin.close();
            return 1;
        }
        else if (command == "AddGene")
        {
            fin>>name>>x1>>x2;
            //cout<<command<<"\t\t"<<name<<"\t"<<x1<<"\t"<<x2<<endl;
            int iX1, iX2;
            istringstream iss1(x1), iss2(x2);
            iss1 >> iX1;
            iss2 >> iX2;

            if (!d.AddGene(name.c_str(), iX1, iX2))
                cout << "Error: gene already present\n";
        }
        else if(command == "AddGeneAlias")
        {
            string name1, name2;
            fin >> name1;
            fin >> name2;
            //cout<<command<<"\t"<<name1<<"\t"<<name2<<endl;
            if (!d.AddGeneAlias(name1.c_str(), name2.c_str()))
            {
                cout << "Error: could not add gene alias\n";
                d.PrintGeneMapping();
            }
        }
        else if(command == "Regulates")
        {
            fin>>name1>>name2;
            //cout<<command<<"\t"<<name1<<"\t"<<name2<<endl;
            if (!g.AddEdge(name1.c_str(), name2.c_str()))
            {
                cout << "Error: could not add edge.\n";
                d.PrintGeneMapping();
            }
        }
        else if(command == "DoesntRegulate")
        {
            fin>>name1>>name2;
            //cout<<command<<"\t"<<name1<<"\t"<<name2<<endl;
            if (!g.DeleteEdge(name1.c_str(), name2.c_str()))
            {
                cout << "Error: could not add edge.\n";
                d.PrintGeneMapping();
            }
        }
        else if (command == "PrintGraph"){
            g.Print();
            d.PrintGeneMapping();
        }
        else if (command == "RemaoveAlias")
        {
            fin>>name;
            //cout<<command<<"\t"<<name<<endl;
            if (!d.RemoveAlias(name.c_str()))
            {
                cout << "Error: gene alias not found\n";
                d.PrintGeneMapping();
            }
        }
        else if(command == "PrintGeneInfo")
        {
            fin>>name;
            //cout<<command<<"\t"<<name<<endl;
            if (!d.PrintGeneInfo(name.c_str()))
                cout << "Error: gene not found\n";
        }
    }
}
int main()
{

  //clock_t t0, t1;
  //t0 = clock();
  GeneDictionary d;
  GeneGraph g(&d);
  ofstream f;
  //f.open("mytest.txt",ios::in);
  int x=ExtractFiles(d,g);
  //f1.open("mytest2.txt");
  f.open("mytest2.txt" ,ios::app);
  //f.seek((sizeof("\n")-ios::end));
  f.seekp(ios::cur-2*(sizeof("Quit\n")));
  //f.seekp(ios::cur-2*(sizeof("Quit\n")));
  //f.seekp(ios::cur-(sizeof("Quit")));
  //fstream fin;
  //f.open("mytest.txt",ios::out | ios::in);
  //int pos=f.tellp();
  //cout<<endl<<pos;
  //f.seekp(pos-5);
  while (true)
    {
      string token;
      cout<<"                                                  GENEMAPPING \n";
      cout<<"-----------------------------------------------------------------------------------------------------------------------";
      cout<<"\n                                                   OPTIONS\n";
      cout<<"AddGene"<<endl;
      cout<<"AddGeneAlias"<<endl;
      cout<<"RemoveAlias"<<endl;
      cout<<"PrintGeneInfo"<<endl;
      cout<<"Regulates"<<endl;
      cout<<"DoesntRegulate"<<endl;
      cout<<"PrintGraph"<<endl;
      cout<<"Quit"<<endl;
      //cout<<"PrintFeedBackLoops"<<endl;
      cout<<"ENTER YOUR CHOICE   :";
      cin >> token;
      if (token == "AddGene")// || token == "QuitAddGene")
      {
        string name, x1, x2;
        cout<<"Enter name           :";
        cin >> name;
        cout<<"Enter the lower bound:";
        cin>> x1;
        cout<<"Enter the upper bound:";
        cin >> x2;
        f<<token<<" "<<name<<" "<<x1<<" "<<x2<<endl;
        int iX1, iX2;
        istringstream iss1(x1), iss2(x2);
        iss1 >> iX1;
        iss2 >> iX2;

        if (!d.AddGene(name.c_str(), iX1, iX2))
            cout << "Error: gene already present\n";
      }
      else if (token == "AddGeneAlias")// || token == "QuitAddGeneAlias")
      {
        string name1, name2;
        cout<<"Enter the Name1    :";
        cin >> name1;
        cout<<"Enter the Name2    :";
        cin >> name2;
        f<<token<<" "<<name1<<" "<<name2<<endl;
        if (!d.AddGeneAlias(name1.c_str(), name2.c_str()))
        {
            cout << "Error: could not add gene alias\n";
            d.PrintGeneMapping();
	    }
	}
    else if (token == "RemoveAlias")// || token == "QuitRemoveAlias")
	{
        string name;
        cout<<"Enter the Name to be removed :";
        cin >> name;
        f<<token<<" "<<name<<endl;
        if (!d.RemoveAlias(name.c_str()))
	    {
	      cout << "Error: gene alias not found\n";
	      d.PrintGeneMapping();
	    }
	}
    else if (token == "PrintGeneInfo")// || token == "QuitPrintGeneInfo")
	{
        string name;
        cout<<"Enter the Gene name to printed :";
        cin >> name;
        f<<token<<" "<<name<<endl;
        if (!d.PrintGeneInfo(name.c_str()))
            cout << "Error: gene not found\n";
	}
    else if (token == "Regulates")// || token == "QuitRegulates")
	{
        string name1, name2;
        cout<<"Enter the Name1  :";
        cin >> name1;
        cout<<"enter the Name2  :";
        cin>> name2;
        f<<token<<" "<<name1<<" "<<name2<<endl;
        if (!g.AddEdge(name1.c_str(), name2.c_str()))
	    {
            cout << "Error: could not add edge.\n";
            d.PrintGeneMapping();
	    }
	}
    else if (token == "DoesntRegulate")// || token == "QuitDoesntRegulate")
	{
        string name1, name2;
        cout<<"Enter the Name1  :";
        cin >> name1;
        cout<<"Enter the Name2  :";
        cin>> name2;
        f<<token<<" "<<name1<<" "<<name2<<endl;
        if (!g.DeleteEdge(name1.c_str(), name2.c_str()))
	    {
            cout << "Error: could not add edge.\n";
            d.PrintGeneMapping();
	    }
	}
    else if (token == "PrintGraph")// || token == "QuitPrintGraph")
	{
        g.Print();
        d.PrintGeneMapping();
	}
    else if (token == "Quit")
    {
            f<<"Quit";
            f.close();
            break;
    }

}


  //t1 = clock();
  //double dt = ((double)t1-t0)/CLOCKS_PER_SEC;
  //cout << "Time: " << dt << "\n" << flush;


  return 0;
}
