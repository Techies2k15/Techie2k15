//The input of the sudoku is in a file named "colors1.txt".It has a list of cells in the form:(row index - column index- color)

#include<iostream>
#include<fstream>
#include<graphics.h>

using namespace std;

int M,N;

class LLnode
{
    int row,column,box,index;
public:
    LLnode* next;
    LLnode();
    LLnode(int,int);
    LLnode(LLnode &);
    LLnode* Insertfront(LLnode*);
    int FindBox();
    int Index();
    void Display();
    friend class Graph;
};

LLnode::LLnode()
{
    row=0;
    column=0;
    box=0;
    index=0;
    next=NULL;
}

LLnode::LLnode(int row,int column)
{
        this->row=row;
        this->column=column;
        this->box=FindBox();
        this->index=Index();
        this->next=NULL;
}

LLnode::LLnode(LLnode &L)
{
    this->row=L.row;
    this->column=L.column;
    this->box=L.box;
    this->index=L.index;
    this->next=NULL;
}

int LLnode::FindBox()
{
    int i,j;
    for(i=0;i<M;++i)
    {
        if( i*M<=row && row<(i+1)*M)
            break;
    }
    for(j=0;j<M;++j)
    {
        if( j*M<=column && column<(j+1)*M)
            break;
    }
    return i*M+j;
}

int LLnode::Index()
{
    return row*N+column;
}

void LLnode::Display()
{
    cout<<"\nRow:"<<row<<" Column:"<<column<<" Box:"<<box<<" index:"<<index;
}

LLnode* Insertfront(LLnode* head,LLnode* newnode)
{
    if(head==NULL)
        head=newnode;
    else
    {
        newnode->next=head;
        head=newnode;
    }
    return head;
}

class Graph
{
    LLnode* vertices;
    LLnode** adjacency;
    int* coloring;
    int* degree;
public:
    Graph();
    void SetVertices();
    void SetAdjacency();
    void SetColoring();
    void ReadColors();
    void PrintColoring();
    void SequentialColoring();
    void LargestDegreeFirst();
    void Display(int);
};

Graph::Graph()
{
    SetVertices();
    SetAdjacency();
    SetColoring();
    ReadColors();
    Display(0);
    //LargestDegreeFirst();
    SequentialColoring();
    Display(1);
}

void Graph::SetVertices()
{
    int v=0;
    vertices=new LLnode[N*N];
    for(int i=0;i<N;++i)
    {
        for(int j=0;j<N;++j)
        {
            LLnode L(i,j);
            vertices[v]=L;
            v++;
        }
    }
    /*
    for(int i=0;i<N*N;++i)
    {
        vertices[i].Display();
    }
    */
}

void Graph::SetAdjacency()
{
    LLnode* temp1;
    LLnode* temp2;
    degree=new int[N*N];
    for(int i=0;i<N*N;++i)
    {
        degree[i]=0;
    }

    adjacency=new LLnode*[N*N];
    for(int i=0;i<N*N;++i)
    {
        adjacency[i]=NULL;
    }

    for(int i=0;i<N*N;++i)
    {
        for(int j=0;j<N*N;++j)
        {
            if(i!=j && i<j)
            {
                temp1=new LLnode(vertices[i]);
                temp2=new LLnode(vertices[j]);

                if(vertices[i].row==vertices[j].row || vertices[i].column==vertices[j].column ||vertices[i].box==vertices[j].box)
                {
                    adjacency[i]=Insertfront(adjacency[i],temp2);
                    adjacency[j]=Insertfront(adjacency[j],temp1);
                    degree[i]++;
                    degree[j]++;
                }
            }
        }
    }
    /*
    for(int i=0;i<N*N;++i)
    {
        cout<<"\nVertex "<<i<<" is adjacent to:";
        LLnode* temp=adjacency[i];
        while(temp!=NULL)
        {
            cout<<" "<<temp->index;
            temp=temp->next;
        }
    }
    */
}

void Graph::SetColoring()
{
    coloring=new int[N*N];
    for(int i=0;i<N*N;++i)
    {
        coloring[i]=-1;
    }
}

void Graph::ReadColors()
{
    int row,column,color;
    ifstream fin("colors1.txt",ios::in);
    while(!fin.eof())
    {
        fin>>row>>column>>color;
        //cout<<"\n"<<row<<" "<<column<<" "<<color;
        LLnode L(row,column);
        coloring[ L.index ]=color;
    }
    fin.close();
}

void Graph::PrintColoring()
{
    for(int i=0;i<N*N;++i)
    {
        cout<<"\nVertex "<<i<<" has color "<<coloring[i];
    }
}

void Graph::SequentialColoring()
{
    for(int i=0;i<N*N;++i)
    {
        if(coloring[i]==-1)
        {
            bool available[N*N];

            for(int j=0;j<N*N;++j)
                available[j]=false;

            LLnode* temp=adjacency[i];
            while(temp!=NULL)
            {
                if(coloring[temp->index]!=-1)
                    available[coloring[temp->index]]=true;
                temp=temp->next;
            }

            int color;
            for(color=0;color<N*N;++color)
            {
                if(available[color]==false)
                {
                    break;
                }
            }
            coloring[i]=color;
        }
    }
}

void Graph::LargestDegreeFirst()
{
    int* copydegree=new int[N*N];
    for(int i=0;i<N*N;++i)
    {
        copydegree[i]=degree[i];
    }

    while(1)
    {
        int* available=new int[N];
        for(int i=0;i<N;++i)
        {
            available[i]=1;
        }

        int maxdegree=copydegree[0];
        for(int i=1;i<N*N;++i)
        {
            if(copydegree[i] > maxdegree)
                maxdegree=copydegree[i];
        }

        if(maxdegree<0)
            break;

        int maxindex=0;
        for(int i=0;i<N*N;++i)
        {
            if( copydegree[i]==maxdegree)
            {
                maxindex=i;
                break;
            }
        }

        if( coloring[maxindex]!=-1)
        {
            copydegree[maxindex]=-1;
            continue;
        }

        LLnode* temp=adjacency[maxindex];
        while(temp!=NULL)
        {
            int index=temp->index;
            if(coloring[index]!=-1)
                available[coloring[index]]=0;
            temp=temp->next;
        }

        for(int i=0;i<N;++i)
        {
                if(available[i]==1)
                {
                    coloring[maxindex]=i;
                    break;
                }
        }

        copydegree[maxindex]=-1;
    }
}

void Graph::Display(int mode)
{
    char str[100];
    if(mode==0)
    {
        strcpy(str,"INITIAL SUDOKU");
    }
    if(mode==1)
    {
        strcpy(str,"FINAL SUDOKU");
    }

    int gdriver=DETECT,gmode;
    initgraph(&gdriver,&gmode,"c:\\tc\\bgi");
    rectangle(150,80,375,120);
    setcolor(11);
    outtextxy(210,100,str);
    setcolor(15);
    int X=150,Y=150;
    int x1,y1,h=25,w=25;
    y1=Y;
    for(int i=0;i<N;++i)
    {
        x1=X;
        for(int j=0;j<N;++j)
        {
                rectangle(x1,y1,x1+h,y1+w);
                int cr=coloring[i*N+j];
                char str[]=" ";
                if(cr==0)
                    strcpy(str,"1");
                else if(cr==1)
                    strcpy(str,"2");
                else if(cr==2)
                    strcpy(str,"3");
                else if(cr==3)
                    strcpy(str,"4");
                else if(cr==4)
                    strcpy(str,"5");
                else if(cr==5)
                    strcpy(str,"6");
                else if(cr==6)
                    strcpy(str,"7");
                else if(cr==7)
                    strcpy(str,"8");
                else if(cr==8)
                    strcpy(str,"9");
                outtextxy(x1+5,y1+5,str);
                x1+=w;
        }
        y1+=h;
    }

    setcolor(11);
    x1=X;
    y1=Y;
    for(int i=0;i<M+1;++i)
    {
        line(x1,y1,x1+N*w,y1);
        y1=Y+M*(i+1)*h;
    }

    x1=X;
    y1=Y;
    for(int i=0;i<M+1;++i)
    {
        line(x1,y1,x1,y1+N*h);
        x1=X+M*(i+1)*h;
    }
    char ch;
    cin>>ch;
    closegraph();
}

main()
{
    M=3;
    N=M*M;
    /*
    LLnode* head=NULL;
    LLnode* temp;
    int i=0;
    for(int i=0;i<N;++i)
    {
        for(int j=0;j<N;++j)
        {
            LLnode L(i,j);
            temp=new LLnode(L);
            head=Insertfront(head,temp);
            //L.Display();
        }
    }
    temp=head;
    while(temp!=NULL)
    {
        temp->Display();
        temp=temp->next;
    }
    */
    Graph G;
    return 0;
}
