import sys
from sample import *
from sample_1 import *
from PyQt4 import QtCore,QtGui,uic
from tkinter import *
import tkinter.messagebox

qtCreatorFile = "Des.ui"
Ui_MainWindow,QtBaseClass = uic.loadUiType(qtCreatorFile)
ObsList = []

class MyApp(QtGui.QMainWindow,Ui_MainWindow):

    
    AdjMat = []
    x=["FFAA00","FFFF00","00FF00","FF0000","FFFFFF","0000FF"]

    def __init__(self):

        QtGui.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)

        self.c = 0
        self.Start = -1
        self.Stop = -1

        for i in range(81):

            j = []
            if not (i)%9 == 0:
                j.append(i-1)
            if not (i+1)%9 == 0:
                j.append(i+1)
            if not i<9:
                j.append(i-9)
            if not i>71:
                j.append(i+9)
            self.AdjMat.append(j)

        self.Button_List = [self.pushButton_1,self.pushButton_2,self.pushButton_3,self.pushButton_4,self.pushButton_5,self.pushButton_6,self.pushButton_7,self.pushButton_8,self.pushButton_9,self.pushButton_10,self.pushButton_11,self.pushButton_12,self.pushButton_13,self.pushButton_14,self.pushButton_15,self.pushButton_16,self.pushButton_17,self.pushButton_18,self.pushButton_19,self.pushButton_20,self.pushButton_21,self.pushButton_22,self.pushButton_23,self.pushButton_24,self.pushButton_25,self.pushButton_26,self.pushButton_27,self.pushButton_28,self.pushButton_29,self.pushButton_30,self.pushButton_31,self.pushButton_32,self.pushButton_33,self.pushButton_34,self.pushButton_35,self.pushButton_36,self.pushButton_37,self.pushButton_38,self.pushButton_39,self.pushButton_40,self.pushButton_41,self.pushButton_42,self.pushButton_43,self.pushButton_44,self.pushButton_45,self.pushButton_46,self.pushButton_47,self.pushButton_48,self.pushButton_49,self.pushButton_50,self.pushButton_51,self.pushButton_52,self.pushButton_53,self.pushButton_54,self.pushButton_55,self.pushButton_56,self.pushButton_57,self.pushButton_58,self.pushButton_59,self.pushButton_60,self.pushButton_61,self.pushButton_62,self.pushButton_63,self.pushButton_64,self.pushButton_65,self.pushButton_66,self.pushButton_67,self.pushButton_68,self.pushButton_69,self.pushButton_70,self.pushButton_71,self.pushButton_72,self.pushButton_73,self.pushButton_74,self.pushButton_75,self.pushButton_76,self.pushButton_77,self.pushButton_78,self.pushButton_79,self.pushButton_80,self.pushButton_81]     

        self.Submit.clicked.connect(self.Done)
        self.Obs.clicked.connect(self.Obst)
        self.Starts.clicked.connect(self.Start1)
        self.Stops.clicked.connect(self.Stop1)
        #self.Revert.clicked.connect(self.Revert)
        self.pushButton_1.clicked.connect(lambda:self.Button(1,self.pushButton_1))
        self.pushButton_2.clicked.connect(lambda:self.Button(2,self.pushButton_2))
        self.pushButton_3.clicked.connect(lambda:self.Button(3,self.pushButton_3))
        self.pushButton_4.clicked.connect(lambda:self.Button(4,self.pushButton_4))
        self.pushButton_5.clicked.connect(lambda:self.Button(5,self.pushButton_5))
        self.pushButton_6.clicked.connect(lambda:self.Button(6,self.pushButton_6))
        self.pushButton_7.clicked.connect(lambda:self.Button(7,self.pushButton_7))
        self.pushButton_8.clicked.connect(lambda:self.Button(8,self.pushButton_8))
        self.pushButton_9.clicked.connect(lambda:self.Button(9,self.pushButton_9))
        self.pushButton_10.clicked.connect(lambda:self.Button(10,self.pushButton_10))
        self.pushButton_11.clicked.connect(lambda:self.Button(11,self.pushButton_11))
        self.pushButton_12.clicked.connect(lambda:self.Button(12,self.pushButton_12))
        self.pushButton_13.clicked.connect(lambda:self.Button(13,self.pushButton_13))
        self.pushButton_14.clicked.connect(lambda:self.Button(14,self.pushButton_14))
        self.pushButton_15.clicked.connect(lambda:self.Button(15,self.pushButton_15))
        self.pushButton_16.clicked.connect(lambda:self.Button(16,self.pushButton_16))
        self.pushButton_17.clicked.connect(lambda:self.Button(17,self.pushButton_17))
        self.pushButton_18.clicked.connect(lambda:self.Button(18,self.pushButton_18))
        self.pushButton_19.clicked.connect(lambda:self.Button(19,self.pushButton_19))
        self.pushButton_20.clicked.connect(lambda:self.Button(20,self.pushButton_20))
        self.pushButton_21.clicked.connect(lambda:self.Button(21,self.pushButton_21))
        self.pushButton_22.clicked.connect(lambda:self.Button(22,self.pushButton_22))
        self.pushButton_23.clicked.connect(lambda:self.Button(23,self.pushButton_23))
        self.pushButton_24.clicked.connect(lambda:self.Button(24,self.pushButton_24))
        self.pushButton_25.clicked.connect(lambda:self.Button(25,self.pushButton_25))
        self.pushButton_26.clicked.connect(lambda:self.Button(26,self.pushButton_26))
        self.pushButton_27.clicked.connect(lambda:self.Button(27,self.pushButton_27))
        self.pushButton_28.clicked.connect(lambda:self.Button(28,self.pushButton_28))
        self.pushButton_29.clicked.connect(lambda:self.Button(29,self.pushButton_29))
        self.pushButton_30.clicked.connect(lambda:self.Button(30,self.pushButton_30))
        self.pushButton_31.clicked.connect(lambda:self.Button(31,self.pushButton_31))
        self.pushButton_32.clicked.connect(lambda:self.Button(32,self.pushButton_32))
        self.pushButton_33.clicked.connect(lambda:self.Button(33,self.pushButton_33))
        self.pushButton_34.clicked.connect(lambda:self.Button(34,self.pushButton_34))
        self.pushButton_35.clicked.connect(lambda:self.Button(35,self.pushButton_35))
        self.pushButton_36.clicked.connect(lambda:self.Button(36,self.pushButton_36))
        self.pushButton_37.clicked.connect(lambda:self.Button(37,self.pushButton_37))
        self.pushButton_38.clicked.connect(lambda:self.Button(38,self.pushButton_38))
        self.pushButton_39.clicked.connect(lambda:self.Button(39,self.pushButton_39))
        self.pushButton_40.clicked.connect(lambda:self.Button(40,self.pushButton_40))
        self.pushButton_41.clicked.connect(lambda:self.Button(41,self.pushButton_41))
        self.pushButton_42.clicked.connect(lambda:self.Button(42,self.pushButton_42))
        self.pushButton_43.clicked.connect(lambda:self.Button(43,self.pushButton_43))
        self.pushButton_44.clicked.connect(lambda:self.Button(44,self.pushButton_44))
        self.pushButton_45.clicked.connect(lambda:self.Button(45,self.pushButton_45))
        self.pushButton_46.clicked.connect(lambda:self.Button(46,self.pushButton_46))
        self.pushButton_47.clicked.connect(lambda:self.Button(47,self.pushButton_47))
        self.pushButton_48.clicked.connect(lambda:self.Button(48,self.pushButton_48))
        self.pushButton_49.clicked.connect(lambda:self.Button(49,self.pushButton_49))
        self.pushButton_50.clicked.connect(lambda:self.Button(50,self.pushButton_50))
        self.pushButton_51.clicked.connect(lambda:self.Button(51,self.pushButton_51))
        self.pushButton_52.clicked.connect(lambda:self.Button(52,self.pushButton_52))
        self.pushButton_53.clicked.connect(lambda:self.Button(53,self.pushButton_53))
        self.pushButton_54.clicked.connect(lambda:self.Button(54,self.pushButton_54))
        self.pushButton_55.clicked.connect(lambda:self.Button(55,self.pushButton_55))
        self.pushButton_56.clicked.connect(lambda:self.Button(56,self.pushButton_56))
        self.pushButton_57.clicked.connect(lambda:self.Button(57,self.pushButton_57))
        self.pushButton_58.clicked.connect(lambda:self.Button(58,self.pushButton_58))
        self.pushButton_59.clicked.connect(lambda:self.Button(59,self.pushButton_59))
        self.pushButton_60.clicked.connect(lambda:self.Button(60,self.pushButton_60))
        self.pushButton_61.clicked.connect(lambda:self.Button(61,self.pushButton_61))
        self.pushButton_62.clicked.connect(lambda:self.Button(62,self.pushButton_62))
        self.pushButton_63.clicked.connect(lambda:self.Button(63,self.pushButton_63))
        self.pushButton_64.clicked.connect(lambda:self.Button(64,self.pushButton_64))
        self.pushButton_65.clicked.connect(lambda:self.Button(65,self.pushButton_65))
        self.pushButton_66.clicked.connect(lambda:self.Button(66,self.pushButton_66))
        self.pushButton_67.clicked.connect(lambda:self.Button(67,self.pushButton_67))
        self.pushButton_68.clicked.connect(lambda:self.Button(68,self.pushButton_68))
        self.pushButton_69.clicked.connect(lambda:self.Button(69,self.pushButton_69))
        self.pushButton_70.clicked.connect(lambda:self.Button(70,self.pushButton_70))
        self.pushButton_71.clicked.connect(lambda:self.Button(71,self.pushButton_71))
        self.pushButton_72.clicked.connect(lambda:self.Button(72,self.pushButton_72))
        self.pushButton_73.clicked.connect(lambda:self.Button(73,self.pushButton_73))
        self.pushButton_74.clicked.connect(lambda:self.Button(74,self.pushButton_74))
        self.pushButton_75.clicked.connect(lambda:self.Button(75,self.pushButton_75))
        self.pushButton_76.clicked.connect(lambda:self.Button(76,self.pushButton_76))
        self.pushButton_77.clicked.connect(lambda:self.Button(77,self.pushButton_77))
        self.pushButton_78.clicked.connect(lambda:self.Button(78,self.pushButton_78))
        self.pushButton_79.clicked.connect(lambda:self.Button(79,self.pushButton_79))
        self.pushButton_80.clicked.connect(lambda:self.Button(80,self.pushButton_80))
        self.pushButton_81.clicked.connect(lambda:self.Button(81,self.pushButton_81))
        
    def Button(self,u,Button):
     
        i = u-1
        
        if self.c == 0 and self.Start == -1 and not self.Stop == i and not i in ObsList:
            #self.pushButton_1.setStyleSheet("font-size:0px;background-color:#"+"FFAA00"+";\border: 2px solid #000000")
            Button.setStyleSheet("font-size:0px;background-color:#7FFF00;\
        border: 2px solid #000000")
            self.Start = i

        if self.c == 1 and self.Stop == -1 and not self.Start == i and not i in ObsList:
            #Button.setStyleSheet("font-size:0px;background-color:#"+"FFFF00"+";\border: 2px solid #000000")
            Button.setStyleSheet("font-size:0px;background-color:#FF0000;\
        border: 2px solid #000000")
            self.Stop = i

        if self.c == 2 and (not i == self.Start and not i == self.Stop):
            #Button.setStyleSheet("font-size:0px;background-color:#"+"00FF00"+";\border: 2px solid #000000")
            Button.setStyleSheet("font-size:0px;background-color:#000000;\
        border: 2px solid #000000")
        
            if not (i)%9 == 0 and not i==0:
                if i-1 in self.AdjMat[i]:
                    self.AdjMat[i].remove(i-1)
                if i in self.AdjMat[i-1]:
                    self.AdjMat[i-1].remove(i)
            if not (i+1)%9 == 0 and not i == 80: 
                if i+1 in self.AdjMat[i]:
                    self.AdjMat[i].remove(i+1)
                if i in self.AdjMat[i+1]:
                    self.AdjMat[i+1].remove(i)
            if not i<9:
                if i-9 in self.AdjMat[i]:
                    self.AdjMat[i].remove(i-9)
                if i in self.AdjMat[i-9]:
                    self.AdjMat[i-9].remove(i)
            if not i>71:
                if i+9 in self.AdjMat[i]:
                    self.AdjMat[i].remove(i+9)
                if i in self.AdjMat[i+9]:
                    self.AdjMat[i+9].remove(i)

            ObsList.append(i)

        
    def Start1(self):
        self.c = 0

    def Stop1(self):
        self.c = 1

    def Obst(self):
        self.c = 2

    def Done(self):
        if self.Start == -1:
            self.Start = 0
             
        if self.Stop == -1:
            self.Stop = 80

       # print(self.AdjMat)
        # print(self.Start)
         # print(self.Stop)

        def Go():
            root.destroy()
            
        root = Tk()
        v = IntVar()
        L = Label(root, text = 'Enter the Option for the Shortest path Algorithm : ')
        r1 = Radiobutton(root,text = "Dijsktra's Algorithm",variable = v,value = 1)
        r2 = Radiobutton(root,text = "A* Algorithm",variable = v,value = 2)
        B = Button(root,text = "Submit",command = Go)
        L.grid()
        r1.grid(row = 1,sticky = 'W')
        r2.grid(row = 2,sticky = 'W')
        B.grid(row = 3)
        mainloop()
        if v==1:
            Load = dijkstra_search(self.AdjMat,self.Start,self.Stop)
        else:
            Load = a_star_search(self.AdjMat,self.Start,self.Stop)
        Fin = reconstruct_path(Load,self.Start,self.Stop)
        if Fin == 0:
            root = Tk()
            root.geometry('100x50')
            root.title('Error')
            L = Label(root,text = 'No path can be Traced',fg = 'red')
            L.pack()
            root.mainloop()
            return(0)
            
        for i in Fin:
            if not i == self.Start and not i == self.Stop:
                self.Button_List[i].setStyleSheet("font-size:0px;background-color:#FFFF00;\
        border: 2px solid #000000")
        
        #sys.exit(app.exec_())

if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec_())
